"""ADMtoTNPCustom.py - TAB customisation for the FX FIX integration.

Author: GGIR

Goes into <TAB_ROOT>\\Msrv\\python\\custom\\ and replaces the FIS
ADMtoTNPCustom.py_template (FCA4853-11 par. 5.9). Requires a TAB restart.

For every currency order book: if one of the two currencies of the pair carries the
DELIVERABLE AddInfo set to false, the pair is an NDF and settles in the other one, which
is added to the TNPORDERBOOK as a free text. If neither is deliverable - a pair that
cannot be traded, out of scope - FX_SETTL_CCY_ERROR is written instead.

    USD/BRL -> "USD"      EUR/USD -> nothing      BRL/INR -> "XERR"

AMAS persists it in orderBooksFdb.InstrumentSubType: see _STORE_FX_SETTL_CCY in
amas customizations/customisedInclude.map, where the constants below are repeated and
have to be kept in sync.
"""
import acm
import log
from protocols import tnp
from utilities import FlowTrack


# A defect in the TAB 2026.1.0 core, not ours: FlowTrack.get_flowtrackpoint_location
# (Msrv\python\utilities.py:680) dereferences message._parent_ on every TNPORDERBOOK, but
# the ones built by ADMtoTNPBase.instrToTNPOrderBook do not have one. That branch is only
# reached when the chain contains a handler loaded from python\CUSTOM (protocol.py:895),
# which is exactly this file: without the wrapper the AttributeError propagates up to
# ADMtoTNPBase:1238 and no order book reaches AMAS. UseFlowTrack=0 is not enough, the
# crash happens before the check on _state. To be removed once FIS fixes the core.
if not getattr(FlowTrack.add_flowtracks, '_fxFixSafe', False):
    _coreAddFlowTracks = FlowTrack.add_flowtracks

    def _addFlowTracks(message, *args, **kwargs):
        try:
            return _coreAddFlowTracks(message, *args, **kwargs)
        except AttributeError:
            return None

    _addFlowTracks._fxFixSafe = True
    FlowTrack.add_flowtracks = _addFlowTracks


# The blob AMAS stores for us, and the two elements we put in it. The id is the one FIS
# uses in this same file's template, addBlobsToOrderBook(): it is the only channel of the
# two that TAB's own comparison looks at.
FX_BLOB_ID = '{BEB68E80-DA2D-4683-B149-C99D22B29948}'
FX_BLOB_TAG_SETTL_CCY = 'FXSETTLCCY'
FX_BLOB_TAG_OPTION = 'FXOPT'
FX_BLOB_TAG_SWAP = 'FXSWAP'

# A pair with no deliverable leg.
FX_SETTL_CCY_ERROR = 'XERR'

# Front Arena settlement types -> SettlMethod(1193).
FX_OPTION_SETTL_METHOD = {'Physical Delivery': 'P', 'Cash': 'C'}

DELIVERABLE_ADDINFO = 'DELIVERABLE'
NON_DELIVERABLE = ('no', 'false', '0')


def _isNonDeliverable(acmCurrency):
    """An empty or absent DELIVERABLE means the currency is deliverable."""
    try:
        value = acmCurrency.AddInfoValue(DELIVERABLE_ADDINFO)
    except Exception as exc:
        log.warning('ADMtoTNPCustom: AddInfo %s not readable: %s'
                    % (DELIVERABLE_ADDINFO, exc))
        return False
    value = '' if value is None else str(value)
    return value.strip().lower() in NON_DELIVERABLE



def _admInstrument(TNPORDERBOOK):
    """The ACM instrument behind the order book, by its ADM_INSID name.

    szMarketInstrumentId is not usable for this: it is the name stripped of separators
    and cut to 16 characters (`FXOPTIONTEST`), not the ACM name (`FX OPTION TEST`).
    ADMtoTNPBase.py:799 puts the real one in a TNPORDERBOOKNAME of type TNP_NT_ADM_INSID.
    """
    for i in range(len(TNPORDERBOOK.TNPORDERBOOKNAME)):
        name = TNPORDERBOOK.TNPORDERBOOKNAME[i]
        if name.dwNameType() == tnp.TNP_NT_ADM_INSID:
            return acm.FInstrument[str(name.szName())]
    return None


def _yyyymmdd(value):
    """Front Arena dates come as 'YYYY-MM-DD'. Returns '' on anything else."""
    text = str(value or '').strip()
    digits = text.replace('-', '')
    return digits if len(digits) == 8 and digits.isdigit() else ''


def _optionRecord(acmInstrument):
    """settlement method + delivery date, packed. '' when incomplete.

    Nothing is defaulted: a missing piece means the order book goes out without the
    record, and the outgoing order is rejected by AMAS rather than sent with a guessed
    settlement method.
    """
    settlType = str(acmInstrument.SettlementType() or '')
    method = FX_OPTION_SETTL_METHOD.get(settlType)
    if not method:
        log.error('ADMtoTNPCustom: option %s has SettlementType %r, expected one of %s'
                  % (acmInstrument.Name(), settlType, sorted(FX_OPTION_SETTL_METHOD)))
        return ''

    delivery = _yyyymmdd(acmInstrument.DeliveryDate())
    if not delivery:
        log.error('ADMtoTNPCustom: option %s has no usable delivery date'
                  % acmInstrument.Name())
        return ''

    return method + delivery


def _swapRecord(acmInstrument):
    """near date + far date + symbol, packed. '' when incomplete.

    An FX swap instrument in Front Arena is two fixed legs sharing the same pair of
    dates: the near date is the legs' StartDate, the far date their EndDate. They are
    read from the first leg, which is enough because both carry the same pair.

    The symbol is built from the currencies: the quote is the instrument currency and
    the base is the currency of the other leg, so EUR/USD on an instrument in USD with
    a EUR leg. The order book cannot supply it - its own instrument is the swap, not
    the pair - which is why it travels here.

    Nothing is defaulted: a missing piece means the order book goes out without the
    record, and the outgoing order is rejected by AMAS rather than sent with guessed
    dates.
    """
    legs = list(acmInstrument.Legs()) if acmInstrument.Legs() else []
    if len(legs) != 2:
        log.error('ADMtoTNPCustom: swap %s has %d legs, expected 2'
                  % (acmInstrument.Name(), len(legs)))
        return ''

    near = _yyyymmdd(legs[0].StartDate())
    far = _yyyymmdd(legs[0].EndDate())
    if not near or not far:
        log.error('ADMtoTNPCustom: swap %s has no usable near/far dates (%r, %r)'
                  % (acmInstrument.Name(), legs[0].StartDate(), legs[0].EndDate()))
        return ''

    quote = acmInstrument.Currency()
    base = None
    for leg in legs:
        currency = leg.Currency()
        if currency and quote and currency.Name() != quote.Name():
            base = currency
            break
    if base is None or quote is None:
        log.error('ADMtoTNPCustom: swap %s: cannot tell base from quote currency'
                  % acmInstrument.Name())
        return ''

    return '%s%s%s/%s' % (near, far, base.Name(), quote.Name())


def _addBlob(TNPORDERBOOK, tag, value):
    """Attach <FRONTARENABlob><AdditionalInfo><tag>value</tag></...>, FIS's own shape.

    Built as a string rather than with ElementTree: the payload is one element with an
    ASCII value - a currency code or a date - so there is nothing to escape, and the
    reader on the AMAS side has no XML parser and cuts between the two tags.
    """
    blob = TNPORDERBOOK.TNPBLOB[len(TNPORDERBOOK.TNPBLOB)]
    blob.BlobId = FX_BLOB_ID
    blob.Data = ('<FRONTARENABlob><AdditionalInfo><%s>%s</%s></AdditionalInfo>'
                 '</FRONTARENABlob>' % (tag, value, tag))


@tnp.outgoing('TNPORDERBOOK')
def mapCustomFields(TNPORDERBOOK):
    try:
        if TNPORDERBOOK.dwInstrumentType() == tnp.TNP_OPTIONS:
            acmInstrument = _admInstrument(TNPORDERBOOK)
            if not acmInstrument:
                log.warning('ADMtoTNPCustom: no ADM instrument on option order book %s'
                            % TNPORDERBOOK.szOrderBookId())
                return None
            expiry = _yyyymmdd(acmInstrument.ExpiryDateOnly())
            if not expiry:
                log.error('ADMtoTNPCustom: option %s has no usable expiry date'
                          % acmInstrument.Name())
                return None
            TNPORDERBOOK.TNPINSTRUMENTOPTION.TNPCONTRACTDATE.szDate = expiry

            record = _optionRecord(acmInstrument)
            if record:
                _addBlob(TNPORDERBOOK, FX_BLOB_TAG_OPTION, record)
            log.info('ADMtoTNPCustom: option %s -> expiry %s, %s'
                     % (acmInstrument.Name(), expiry, record or '<incompleto>'))
            return None

        if TNPORDERBOOK.dwInstrumentType() == tnp.TNP_SWAP:
            acmInstrument = _admInstrument(TNPORDERBOOK)
            if not acmInstrument:
                log.warning('ADMtoTNPCustom: no ADM instrument on swap order book %s'
                            % TNPORDERBOOK.szOrderBookId())
                return None
            record = _swapRecord(acmInstrument)
            if record:
                _addBlob(TNPORDERBOOK, FX_BLOB_TAG_SWAP, record)
            log.info('ADMtoTNPCustom: swap %s -> %s'
                     % (acmInstrument.Name(), record or '<incomplete>'))
            return None

        # The two legs are read from the TNP order book, not from the ADM message.
        #
        # >>> They used to be taken from admtotnp.message: the instrument as the base leg
        # >>> and message['OrderBook'].Currency() as the quote leg. But 'OrderBook' is not
        # >>> in the message on this path, and the fallback instrument.Currency() on an
        # >>> FCurrency returns the currency itself: both legs ended up identical, no pair
        # >>> came out as an NDF and the free text was never sent. Verified on 26/08 with
        # >>> a probe: the handler ran on all 1879 order books without logging one line.
        #
        # szMarketInstrumentId and szTradingCurrency are always populated - they have just
        # been written by ADMtoTNPBase.instrToTNPOrderBook - and they are the same two
        # fields AMAS builds Symbol(55) from.
        base = acm.FCurrency[TNPORDERBOOK.szMarketInstrumentId()]
        quote = acm.FCurrency[TNPORDERBOOK.szTradingCurrency()]
        if not base or not quote:
            return None

        baseNdf = _isNonDeliverable(base)
        quoteNdf = _isNonDeliverable(quote)
        if not (baseNdf or quoteNdf):
            return None

        if baseNdf and quoteNdf:
            # No leg to settle in: an empty field would read as "deliverable".
            settlCcy = FX_SETTL_CCY_ERROR
            log.error('ADMtoTNPCustom: %s/%s, both non-deliverable'
                      % (base.Name(), quote.Name()))
        else:
            settlCcy = quote.Name() if baseNdf else base.Name()
            log.info('ADMtoTNPCustom: %s/%s is an NDF, settles in %s'
                     % (base.Name(), quote.Name(), settlCcy))

        _addBlob(TNPORDERBOOK, FX_BLOB_TAG_SETTL_CCY, settlCcy)
    except Exception as exc:
        # An order book without the field is better than an order book not created.
        log.warning('ADMtoTNPCustom: custom fields not determined: %s' % exc)

    return None

"""FXOptionInstrument.py - booking of FX vanilla options, solicited and unsolicited.

Author: GGIR

Goes into <TAB_ROOT>\\Msrv\\python\\custom\\ (FCA4853-11 par. 4.1: "the custom layer where
customer handlers must go"). The file name does not matter, the .py extension does; with
several files the import order is alphabetical (par. 4.5). Requires a TAB restart.

WHAT IT DOES
------------
Two flows, one rule each.

  SOLICITED    the order left PRIME on the option's own order book, so the deal already
               carries that order book and INSADDR resolves onto the option instrument
               that exists in PRIME. Nothing to do: the handler steps aside.

  UNSOLICITED  there is no order on our side. AMAS resolves the order book from
               Symbol(55) alone - getOrderBook() does
               orderBooksFdb.get("MarketInstrumentTradingId", Symbol),
               FIXOrderCommonFunctions.map:177 - so an option on EUR/CHF lands on the
               EUR/CHF **spot** order book and would book onto the currency instrument.
               Here the option asset is created and INSADDR corrected.

The two are told apart by the instrument type of the order book the deal carries: an
option order book means solicited, anything else means the message came in on its own.

THE NAME OF THE CREATED ASSET
-----------------------------
    MF_<CCY1CCY2>_<P|C>_<E|A>_<STRIKE>_<EXPIRY>

    MF_EURCHF_P_E_1.27_20261127

The name describes the **contract**, and nothing else: one asset per distinct economic
option, however many deals are done on it. Put/call and exercise style are part of it
because without them a call and a put with the same strike and expiry would collide onto
one instrument, and the second trade would book onto the first one's asset with nothing
looking wrong.

`OrderID(37)` is deliberately **not** in the name. What tells one deal from another is the
`MARKETORDERID` AddInfo on the trade, which this handler fills - see below. That also
makes the lookup naturally idempotent: repeated ExecutionReports and partial fills all
resolve to the same asset, and the lookup always precedes the creation.

Front Arena truncates instrument names at **63 characters, silently**: measured, a 64
character name comes back as 63. Over that limit the underscores between put/call,
exercise style and strike are dropped first; if it still does not fit the trade is
refused rather than booked onto a truncated, colliding name.

MARKETORDERID ON THE TRADE
--------------------------
`OrderID(37)` is the counterparty's order id, stable for the whole life of the order. The
core already writes it as the `MARKETORDERID` AddInfo, but **only on unsolicited deals**:
`base/trade_generic.py:267` reads `TNPDEAL.TNPMARKETORDERID.szMarketOrderId`, which AMAS
populates in `ExecutionReport2McDeal_ext()` alone (`FIXOrderCommon.map:2742`). On the
solicited path that field is empty and the AddInfo comes out unset - measured on trade
10019 of 27/08.

So this handler sets it from the blob when the core has not, on both paths. That is what
distinguishes two deals on the same option.

SCOPE
-----
FX vanilla only, as the project scope says: **European and American exercise**.
Anything else that reaches this handler is a message we cannot represent, so the booking
is **stopped** - booking it would put a trade on an asset that does not describe it.
Rejected here: options whose Product(460) is not 4 (CURRENCY), those whose
OptPayoutType(1482) is not 1 (VANILLA), and **Bermudan exercise** (1194=2). Non-FX
options are rejected on the outbound side too, in AMAS, before they reach the wire.

>>> Bermudan was supported for a few hours on 27/08 and then removed, by decision of the
>>> user. Front Arena does model it - `ExerciseType` accepts `Bermudan` and FExerciseEvent
>>> carries the schedule - and FIX can carry the exercise dates in the EvntGrp repeating
>>> group. It was dropped because it is out of the agreed scope, not because it could not
>>> be done: if it comes back, the ingredients are ExerciseStyle(1194)=2, an EvntGrp with
>>> one EventDate(866) per exercise date, and one FExerciseEvent per date on the
>>> instrument.

"""
import acm
import log
from protocols import tnp, amba
from protocols.tnp import blob
from protocols.amba import refs, addinfo
from caching import orderbooks

# The incoming FIX message, serialised, that AMAS appends to the deal.
# FIXOrderCommon.map:379 MAP_JSONTrade(), active with MI\Parameters\UseJSONTradeBlob = 1.
JSON_BLOB_ID = '{2c7dff83-a4c9-4158-9ee9-f4ca37f5897e}'

# SecurityType(167) of an option. FIX 5.0 SP2 has no FX-specific option value - the 167
# enumeration has FXSPOT / FXFWD / FXNDF / FXSWAP and, for options, only the generic OPT.
# An FX option is therefore OPT plus Product(460)=4. See the addendum to the pricer spec.
SECURITY_TYPE_OPTION = 'OPT'
PRODUCT_CURRENCY = '4'
OPT_PAYOUT_VANILLA = '1'

PUT_CALL = {'0': ('P', 'Put'), '1': ('C', 'Call')}
EXERCISE = {'0': ('E', 'European'), '1': ('A', 'American')}
SETTLEMENT_TYPE = {'P': 'Physical Delivery', 'C': 'Cash'}

# Measured on this ADS: a 64 character name is stored as 63, without an error.
MAX_NAME = 63

# Taken from the reference option in PRIME, `FX OPTION TEST`, read field by field.
# >>> PayDayOffset is 1 there against the 2 spot banking days. Whether that is a premium
# >>> settlement convention or a property of that one instrument is not established:
# >>> it is mirrored, not derived, and has to be confirmed before production.
QUOTATION = 'Points of UndCurr'
CONTRACT_SIZE = 1.0
PAY_TYPE = 'Spot'
SPOT_BANKING_DAYS = 2
PAY_DAY_OFFSET = 1


class FXOptionNotSupported(Exception):
    """An option this integration cannot represent.

    Internal control flow only: the handler turns it into the abort string the protocol
    layer expects. See the note on the stop mechanism in the module docstring.
    """


def _body(TNPDEAL):
    """The Body section of the serialised FIX message AMAS appends to the deal.

    Subscripts, not dot notation: the blob is a ForgivingAttrDict and a wrong path does
    not raise, it returns an empty string that propagates silently.
    """
    return blob(TNPDEAL.TNPBLOB, blobId=JSON_BLOB_ID)['Body']


def _isSolicited(TNPDEAL):
    """True when the deal came in on the option's own order book.

    On that path the order book's TAB alias already points at the option instrument in
    PRIME and INSADDR is right, so this handler must not touch it.
    """
    TNPORDERBOOK = orderbooks.get(TNPDEAL.szOrderBookId())
    if not TNPORDERBOOK:
        return False
    try:
        return int(TNPORDERBOOK.dwInstrumentType()) == tnp.TNP_OPTIONS.value
    except Exception:
        return False


def _strike(raw):
    """The strike as it goes in the name: trailing zeros dropped.

    1.2700 and 1.27 are the same strike, and they must not produce two assets for the
    same order. Anything unparsable is kept verbatim rather than guessed at.
    """
    text = str(raw or '').strip()
    try:
        value = float(text)
    except ValueError:
        return text
    out = ('%.10f' % value).rstrip('0').rstrip('.')
    return out or '0'


def _setMarketOrderId(TNPDEAL, body):
    """Put OrderID(37) on the trade as the MARKETORDERID AddInfo.

    It is what tells two deals on the same option apart, now that the OrderID is no
    longer in the instrument name. The core only writes it on unsolicited deals, so on
    the solicited path this is the only thing that fills it.

    The typed field is tried first and the blob is the fallback, where tag 37 is always
    present. A missing OrderID does not stop the booking - the trade is complete without
    it - but it is logged, because the counterparty is required to send it.
    """
    orderId = str(TNPDEAL.TNPMARKETORDERID.szMarketOrderId() or body['OrderID'] or '')
    if not orderId:
        log.warning('FXOptionInstrument: deal %s carries no OrderID(37), '
                    'the trade is booked without MARKETORDERID' % TNPDEAL.szDealId())
        return
    addinfo(amba.messages['xr'].TRADE.ADDITIONALINFO).MARKETORDERID = orderId


def _instrumentName(pair, pcLetter, styleLetter, strike, expiry):
    """MF_<CCY1CCY2>_<P|C>_<E|A>_<STRIKE>_<EXPIRY>, shortened if it must be."""
    full = 'MF_%s_%s_%s_%s_%s' % (pair, pcLetter, styleLetter, strike, expiry)
    if len(full) <= MAX_NAME:
        return full

    # First fallback: drop the underscores between put/call, exercise style and strike.
    compact = 'MF_%s_%s%s%s_%s' % (pair, pcLetter, styleLetter, strike, expiry)
    if len(compact) <= MAX_NAME:
        log.info('FXOptionInstrument: name shortened to %s (%d chars)' % (compact, len(compact)))
        return compact

    return None


def _readOption(TNPDEAL, body):
    """Everything needed to describe the option, validated. Raises when it is out of scope."""
    product = str(body['Product'] or '')
    if product != PRODUCT_CURRENCY:
        raise FXOptionNotSupported(
            'Product(460)=%r, expected %s (CURRENCY): this is not an FX option'
            % (product, PRODUCT_CURRENCY))

    payout = str(body['OptPayoutType'] or '')
    if payout != OPT_PAYOUT_VANILLA:
        raise FXOptionNotSupported(
            'OptPayoutType(1482)=%r, expected %s (VANILLA): exotic options are out of scope'
            % (payout, OPT_PAYOUT_VANILLA))

    putCall = str(body['PutOrCall'] or '')
    if putCall not in PUT_CALL:
        raise FXOptionNotSupported('PutOrCall(201)=%r, expected 0 (Put) or 1 (Call)' % putCall)

    style = str(body['ExerciseStyle'] or '')
    if style not in EXERCISE:
        raise FXOptionNotSupported(
            'ExerciseStyle(1194)=%r: only 0 (European) and 1 (American) are in scope'
            % style)

    settlMethod = str(body['SettlMethod'] or '')
    if settlMethod not in SETTLEMENT_TYPE:
        raise FXOptionNotSupported(
            'SettlMethod(1193)=%r, expected P (physical) or C (cash)' % settlMethod)

    symbol = str(body['Symbol'] or '')
    if '/' not in symbol:
        raise FXOptionNotSupported('Symbol(55)=%r is not in A/B form' % symbol)
    ccy1, ccy2 = symbol.split('/', 1)

    strike = _strike(body['StrikePrice'])
    if not strike or strike == '0':
        raise FXOptionNotSupported('StrikePrice(202)=%r' % (body['StrikePrice'],))

    expiry = str(body['MaturityDate'] or '')
    if len(expiry) != 8 or not expiry.isdigit():
        raise FXOptionNotSupported('MaturityDate(541)=%r, expected YYYYMMDD' % expiry)

    return {
        'ccy1': ccy1, 'ccy2': ccy2,
        'putCall': putCall, 'style': style, 'settlMethod': settlMethod,
        'strike': strike, 'expiry': expiry,
    }


def _findOrCreate(name, opt):
    """Look up by name, create only when absent.

    The lookup always precedes the creation, so a repeated ExecutionReport or a second
    partial fill of the same order never produces a duplicate.

    Equality lookup on purpose: in ASQL the wildcard is `*`, not `%`, and `name like
    'MF_%'` silently returns nothing. `name='...'` is not affected.
    """
    ins = acm.FInstrument.Select01("name='%s'" % name, None)
    if ins:
        return ins

    underlying = acm.FCurrency[opt['ccy1']]
    currency = acm.FCurrency[opt['ccy2']]
    if not underlying or not currency:
        raise FXOptionNotSupported(
            'currency not found in PRIME (%s / %s)' % (opt['ccy1'], opt['ccy2']))

    ins = acm.FOption()
    ins.Name(name)
    ins.Currency(currency)                       # terms currency: the B of A/B
    ins.Underlying(underlying)                   # base currency: the A of A/B
    ins.StrikePrice(float(opt['strike']))
    ins.ExpiryDate(opt['expiry'])                # accepts YYYYMMDD, i.e. raw tag 541
    ins.OptionType(PUT_CALL[opt['putCall']][1])
    ins.ExerciseType(EXERCISE[opt['style']][1])
    ins.SettlementType(SETTLEMENT_TYPE[opt['settlMethod']])
    ins.Quotation(QUOTATION)
    ins.ContractSize(CONTRACT_SIZE)
    ins.PayType(PAY_TYPE)
    ins.Otc(True)                                # required on every asset created here
    ins.SpotBankingDaysOffset(SPOT_BANKING_DAYS)
    ins.PayDayOffset(PAY_DAY_OFFSET)
    ins.Commit()

    log.info('FXOptionInstrument: created %s (%s/%s %s %s strike=%s exp=%s settl=%s, OTC)'
             % (name, opt['ccy1'], opt['ccy2'],
                PUT_CALL[opt['putCall']][1], EXERCISE[opt['style']][1],
                opt['strike'], opt['expiry'], SETTLEMENT_TYPE[opt['settlMethod']]))
    return ins


@tnp.incoming('MCDEAL')
def fx_option_instrument(MCDEAL):
    """On unsolicited option deals, create the OTC asset and book the trade onto it.

    Returns a reason string to abort the booking, None to let it through.
    """
    TNPDEAL = MCDEAL.TNPDEAL

    body = _body(TNPDEAL)
    if str(body['SecurityType'] or '') != SECURITY_TYPE_OPTION:
        return                      # not an option: the forward/NDF handler or a spot

    # On both paths: the OrderID is what distinguishes two deals on the same option.
    _setMarketOrderId(TNPDEAL, body)

    if _isSolicited(TNPDEAL):
        # The order book is the option's own, so INSADDR already points at the instrument
        # that exists in PRIME. Nothing to correct.
        return

    try:
        opt = _readOption(TNPDEAL, body)

        pair = opt['ccy1'] + opt['ccy2']
        name = _instrumentName(pair, PUT_CALL[opt['putCall']][0], EXERCISE[opt['style']][0],
                               opt['strike'], opt['expiry'])
        if name is None:
            raise FXOptionNotSupported(
                'the name of the asset exceeds %d characters even shortened; refusing '
                'rather than booking on a truncated name' % MAX_NAME)

        ins = _findOrCreate(name, opt)
    except FXOptionNotSupported as exc:
        return ('FXOptionInstrument: deal %s not booked - %s'
                % (TNPDEAL.szDealId(), exc))

    AMB = amba.messages['xr']       # the INSERT_TRADE already mapped by base/trade_generic
    refs(AMB.TRADE.INSADDR).INSID = ins.Name()
    log.info('FXOptionInstrument: unsolicited deal %s booked on %s'
             % (TNPDEAL.szDealId(), ins.Name()))

"""FXForwardInstrument.py - dedicated instrument for forwards and NDFs.

Author: GGIR

Goes into <TAB_ROOT>\\Msrv\\python\\custom\\ (FCA4853-11 par. 4.1: "the custom layer where
customer handlers must go"). The file name does not matter, the .py extension does.
Requires a TAB restart.

THE PROBLEM
-----------
A forward order books exactly like a spot, onto the same currency instrument. The outgoing
FIX is correct (167=FXFWD, 63=6, 64=YYYYMMDD), but the trade lands on the wrong
instrument: in base/trade_generic.py:193 the INSADDR is resolved from the order book's TAB
alias, which points at the currency.

HOW IT WORKS
------------
FCA4853-11 par. 4.1: when a custom handler is called, the AMB message has already been
built by the preceding layers and "can be read and modified before sending it", through
amba.messages['xr']. So xr_deal is not rewritten: only INSADDR is corrected.

WHEN IT CANNOT DO THAT
----------------------
If the instrument cannot be resolved, the booking is **stopped**: leaving the message
alone would book the forward onto the currency instrument, which is the very defect this
file exists to fix, and it would do it silently.

>>> The stop is done by **returning a reason string**, not by raising and not by a bare
>>> return. `AbortOnError` is unset, i.e. 0 (component key TAB_FXO/Parameters, core.py:26),
>>> so protocol.py:944 catches an exception, logs "Message will still be sent" and books
>>> the trade anyway. A returned string is a deliberate abort (protocol.py:958-990): the
>>> outgoing messages are cleared and nothing is booked. Measured on 27/08 on the twin
>>> handler for options.

The instrument is an FFuture / Future/Forward, derived from the two reference instruments
in PRIME (trade 4 = deliverable forward, trade 5 = NDF). The only difference between them
is SettlementType. Detail and verification in developments/fwd_instrument/README.md.
"""
import acm
import log
from protocols import tnp, amba
from protocols.tnp import blob
from protocols.amba import refs
from caching import orderbooks

# The incoming FIX message, serialised, that AMAS appends to the deal.
# FIXOrderCommon.map:379 MAP_JSONTrade(), active with MI\Parameters\UseJSONTradeBlob = 1.
JSON_BLOB_ID = '{2c7dff83-a4c9-4158-9ee9-f4ca37f5897e}'

# The names are keyed on OrderID(37), not on ClOrdID(11): the first is stable for the whole
# life of the order, the second changes on every amend and would scatter the fills of one
# operation across different instruments.
PREFIX = {'FXFWD': 'MF_FWRD_', 'FXNDF': 'MF_NDF_FWRD_'}

# An FX swap arrives as a multileg execution, so SecurityType at message level is MLEG
# and says nothing about the leg: the real type is per leg, in LegSecurityType. AMAS
# splits the report into one deal per leg and gives each its own settlement date, so by
# the time a deal gets here it IS a single-dated forward - which is why a leg books onto
# its own generated instrument, distinguished from the other leg by the date in the name.
#
# Which of the two forward types it is depends on the pair, not on the leg: an FX swap
# on a non-deliverable pair is an NDS and both its legs are cash settled. The pair is
# already in hand here, so it is asked directly rather than read off the message - see
# _isNonDeliverablePair.
SWAP_SECURITY_TYPE = 'MLEG'

# Deliverability of a currency, the same rule ADMtoTNPCustom applies when it decides the
# NDF settlement currency to put on an order book: an empty or absent DELIVERABLE means
# deliverable. Kept as its own small copy on purpose - importing across custom handlers
# would tie the booking path to the reference-data path, and a failure in one would take
# the other down with it. If the rule ever changes, it changes in both files.
DELIVERABLE_ADDINFO = 'DELIVERABLE'
NON_DELIVERABLE = ('no', 'false', '0')

# From the reference instruments: identical on forwards and NDFs.
QUOTATION = 'Per Unit Inverse'
CONTRACT_SIZE = 1.0
PAY_TYPE = 'Forward'
SETTLEMENT_TYPE = {'FXFWD': 'Physical Delivery', 'FXNDF': 'Cash'}
DEFAULT_SPOT_DAYS = 2

_blobShapeLogged = False


class FXForwardNotBookable(Exception):
    """The dedicated instrument cannot be resolved.

    Internal control flow only: the handler turns it into the abort string the protocol
    layer expects. See the note on the stop mechanism in the module docstring.
    """


def _logBodyOnce(body):
    """Once only, to pin down the field names if something does not add up.
    This is not a debug trace meant to be left on."""
    global _blobShapeLogged
    _blobShapeLogged = True
    log.warning('FXForwardInstrument: SecurityType missing. Keys of Body: %s'
                % (sorted(body.keys()) if isinstance(body, dict) else repr(body)))


def _body(TNPDEAL):
    """The Body section of the serialised FIX message AMAS appends to the deal.

    The message has three sections: Header, Body, Trailer. The application fields live in
    Body. Verified on 26/08 by logging the top-level keys of a real blob:
    ['Body', 'Header', 'Trailer', 'blobId'].

    It is accessed with **subscripts**, not with dot notation. The blob is a
    ForgivingAttrDict and a wrong path does not raise: it returns an empty string that
    propagates silently, and that is how such a mistake goes unnoticed.

    Not to be confused with jsonBlob.TrdCaptRpt.* which TAB uses elsewhere: that is the
    root of a TradeCaptureReport, and we send ExecutionReports.
    """
    return blob(TNPDEAL.TNPBLOB, blobId=JSON_BLOB_ID)['Body']


def _orderId(TNPDEAL, body):
    """OrderID(37), the stable key of the order.

    On the **solicited** path AMAS does not populate TNPMARKETORDERID: it only does so for
    unsolicited deals, in ExecutionReport2McDeal_ext() (FIXOrderCommon.map:2742, under the
    comment "Unsolicited deals, i.e. deals for which we have no order in the AMAS"). The
    normal path, ExecutionReport2McDeal(), only sets szSourceId = FSMOrderId, which is the
    TNP id of the order, not the counterparty's OrderID.

    So the typed field is tried first - that way this works on unsolicited deals too - and
    the blob is the fallback, where tag 37 is always present.
    """
    oid = TNPDEAL.TNPMARKETORDERID.szMarketOrderId()
    if oid:
        return str(oid)
    return str(body['OrderID'] or '')


def _spotDays(ccy1, ccy2):
    """Spot banking days of the pair, falling back to the default when not configured.

    The pair name carries no separator: EURCNY, not EUR/CNY. The slash was dropped on
    26/08 because it leaked into the order books' ExternalId and stopped matching the id
    AMAS uses - see developments/currency_pairs/README.md.
    """
    pair = acm.FCurrencyPair.Select01("name='%s%s'" % (ccy1, ccy2), None)
    if not pair:
        pair = acm.FCurrencyPair.Select01("name='%s%s'" % (ccy2, ccy1), None)
    if pair:
        try:
            return int(pair.SpotBankingDaysOffset())
        except Exception:
            pass
    return DEFAULT_SPOT_DAYS


def _isNonDeliverable(ccyName):
    """True when the currency is flagged non-deliverable in PRIME."""
    currency = acm.FCurrency[ccyName]
    if not currency:
        return False
    try:
        value = currency.AddInfoValue(DELIVERABLE_ADDINFO)
    except Exception as exc:
        log.warning('FXForwardInstrument: %s on %s not readable: %s'
                    % (DELIVERABLE_ADDINFO, ccyName, exc))
        return False
    # AddInfoValue hands a non-deliverable currency back as the BOOLEAN False, not as a
    # string, so it is turned into text before being compared. A truth test here would
    # read False as "nothing set" and quietly call the currency deliverable - the very
    # fault this function exists to prevent.
    value = '' if value is None else str(value)
    return value.strip().lower() in NON_DELIVERABLE


def _swapLegType(ccy1, ccy2):
    """The forward type a swap leg books as: FXNDF on a non-deliverable pair.

    One non-deliverable leg is enough to make the pair non-deliverable, exactly as on a
    single order: the trade then settles in the other currency and nothing is delivered.
    A pair with neither currency deliverable never gets this far - the order is refused
    at entry with INVALID_FX_NO_SETTL_CCY - so it is not second-guessed here.
    """
    if _isNonDeliverable(ccy1) or _isNonDeliverable(ccy2):
        return 'FXNDF'
    return 'FXFWD'


def _nameDate(valueDate):
    """The value date as YYYYMMDD, for the instrument name.

    TNP hands the settlement date over as the raw tag 64 already, but a separator or
    a trailing time would end up inside the name, so only the digits are kept.
    """
    digits = ''.join(c for c in str(valueDate) if c.isdigit())
    return digits[:8]


def _findOrCreate(name, secType, ccy1, ccy2, valueDate):
    """Look up by name, and create only when absent. The lookup always precedes creation,
    so a repeated ExecutionReport or a partial fill never produces duplicates."""
    ins = acm.FInstrument.Select01("name='%s'" % name, None)
    if ins:
        return ins

    curr1 = acm.FCurrency[ccy1]
    curr2 = acm.FCurrency[ccy2]
    if not curr1 or not curr2:
        raise FXForwardNotBookable(
            'currency not found in PRIME (%s / %s), instrument %s not created'
            % (ccy1, ccy2, name))

    spotDays = _spotDays(ccy1, ccy2)

    ins = acm.FFuture()
    ins.Name(name)
    ins.Currency(curr1)
    ins.Underlying(curr2)
    ins.Quotation(QUOTATION)
    ins.ContractSize(CONTRACT_SIZE)
    ins.ExpiryDate(valueDate)          # accepts YYYYMMDD, i.e. raw tag 64
    ins.PayType(PAY_TYPE)
    ins.SettlementType(SETTLEMENT_TYPE[secType])
    ins.Otc(True)
    ins.SpotBankingDaysOffset(spotDays)
    ins.PayDayOffset(spotDays)         # by decision: same as the spot banking days
    ins.Commit()

    log.info('FXForwardInstrument: created %s (%s %s/%s exp=%s settl=%s)'
             % (name, secType, ccy1, ccy2, valueDate, SETTLEMENT_TYPE[secType]))
    return ins


@tnp.incoming('MCDEAL')
def fx_dedicated_instrument(MCDEAL):
    """On forward and NDF deals, move the trade onto the dedicated instrument.

    Returns a reason string to abort the booking, None to let it through.
    """
    TNPDEAL = MCDEAL.TNPDEAL

    body = _body(TNPDEAL)
    secType = str(body['SecurityType'] or '')
    isSwapLeg = secType == SWAP_SECURITY_TYPE
    if not isSwapLeg and secType not in PREFIX:
        if secType == '' and not _blobShapeLogged:
            _logBodyOnce(body)
        return          # a spot, an option, or SecurityType missing: leave it alone

    try:
        orderId = _orderId(TNPDEAL, body)
        if not orderId:
            raise FXForwardNotBookable(
                'it is %s but carries no OrderID(37), so the instrument cannot be named'
                % secType)

        valueDate = TNPDEAL.szSettlementDate()
        if not valueDate:
            raise FXForwardNotBookable(
                'it is %s but carries no settlement date' % secType)

        TNPORDERBOOK = orderbooks.get(TNPDEAL.szOrderBookId())
        if not TNPORDERBOOK:
            raise FXForwardNotBookable(
                'order book %s is not in the cache' % TNPDEAL.szOrderBookId())

        # The same two legs Symbol = CCY1/CCY2 is built from.
        ccy1 = TNPORDERBOOK.szMarketInstrumentId()
        ccy2 = TNPORDERBOOK.szTradingCurrency()

        # Only now can a swap leg be typed: it takes the pair, and the pair comes from
        # the leg's own order book, which _CM_FC_getOrderBookLeg resolved from
        # LegSymbol(600). The swap's own order book would have given the swap
        # instrument instead.
        if isSwapLeg:
            secType = _swapLegType(ccy1, ccy2)

        # The value date is part of the name. On a single forward it makes the
        # instrument self-describing; on an FX swap it is what tells the two legs
        # apart, since both are booked from the same order and therefore carry the
        # same OrderID - near and far differ only by date.
        name = '%s%s_%s' % (PREFIX[secType], orderId, _nameDate(valueDate))
        ins = _findOrCreate(name, secType, ccy1, ccy2, valueDate)
    except FXForwardNotBookable as exc:
        return ('FXForwardInstrument: deal %s not booked - %s'
                % (TNPDEAL.szDealId(), exc))

    AMB = amba.messages['xr']       # the INSERT_TRADE already mapped by base/trade_generic
    refs(AMB.TRADE.INSADDR).INSID = ins.Name()
    log.info('FXForwardInstrument: deal %s booked on %s'
             % (TNPDEAL.szDealId(), ins.Name()))

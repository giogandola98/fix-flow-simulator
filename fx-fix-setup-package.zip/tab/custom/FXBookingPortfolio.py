"""FXBookingPortfolio.py - the booking portfolio comes from Account(1).

Author: GGIR

Goes into <TAB_ROOT>\\Msrv\\python\\custom\\ (FCA4853-11 par. 4.1). Requires a TAB restart.

THE PROBLEM
-----------
Every trade was booking into DEFAULT_POOL, whatever Account(1) carried. Measured on the
unsolicited option of 27/08: the message carried 1=FX_TRADING and the trade landed in
DEFAULT_POOL, and the same is true of the forwards and NDFs booked on 26/08.

The account does reach TAB - AMAS maps it in
`TNPDEAL.ReferenceData.szAccountId ifexist(Account)` (FIXOrderCommon.map:2743 on the
unsolicited path, MAP_McDeal on the solicited one) - but `base/trade_generic.py:219` puts
it in `TRADE.ACCOUNT`, which is a **text field**. Nothing in the base layer ever sets the
portfolio reference, so the ADS falls back to its default pool.

WHAT IT DOES
------------
Sets the portfolio reference on the trade the previous layers have already built:

    refs(AMB.TRADE.PRFNBR).PRFID = <Account(1)>

`PRFNBR.PRFID` is the reference path of the AMB trade record - it sits in ambashr.dll
right next to `CURR.INSID` and `COUNTERPARTY_PTYNBR.PTYID`, the two the base layer
already uses through `refs()`.

NO FALLBACK, BY DESIGN
----------------------
CLAUDE.md: *"An ExecutionReport without Account(1), or with an Account that does not match
the order's, is a defect: surface it loudly, do not guess the portfolio or fall back to a
default."*

So a missing Account, or one that matches no portfolio in PRIME, **stops the booking**.
A trade in the wrong book is a real position in the wrong place, it reconciles against
nothing, and nobody notices - worse than a trade that does not book and says why.

>>> How the stop is done matters. **Raising is not enough**: with
>>> `AbortOnError` unset, i.e. 0 (component key TAB_FXO/Parameters, core.py:26), protocol.py:944 catches the exception,
>>> logs "Message will still be sent" and books the trade anyway. Measured on 27/08: an
>>> ExecutionReport with Account(1)=NO_SUCH_PORTFOLIO raised here and still landed in
>>> DEFAULT_POOL - the exact fallback this handler exists to prevent.
>>>
>>> A handler that **returns a string** is instead treated as a deliberate abort
>>> (protocol.py:958-990): the reason is logged as "handlers aborted by ...", the
>>> outgoing messages are cleared, and with a generic flow the whole chain stops. That is
>>> the mechanism used here.
"""
import acm
import log
from protocols import tnp, amba
from protocols.amba import refs


def _portfolio(account):
    """The physical portfolio named by Account(1).

    The exact string is tried first, then the upper-case form: the core stores the
    account upper-cased in TRADE.ACCOUNT (trade_generic.py:219) and Front Arena portfolio
    names are conventionally upper case, but the name on the wire is whatever the
    counterparty sends.
    """
    pf = acm.FPhysicalPortfolio[account]
    if pf:
        return pf
    upper = account.upper()
    if upper != account:
        return acm.FPhysicalPortfolio[upper]
    return None


@tnp.incoming('MCDEAL')
def fx_booking_portfolio(MCDEAL):
    """Book the trade into the portfolio Account(1) names.

    Returns a reason string to abort the booking, None to let it through.
    """
    TNPDEAL = MCDEAL.TNPDEAL

    account = (TNPDEAL.ReferenceData.szAccountId() or '').strip()
    if not account:
        return ('FXBookingPortfolio: deal %s carries no Account(1). The booking portfolio '
                'is not known and must not be guessed: trade not booked.'
                % TNPDEAL.szDealId())

    pf = _portfolio(account)
    if not pf:
        return ('FXBookingPortfolio: deal %s carries Account(1)=%r, which matches no '
                'physical portfolio in PRIME: trade not booked.'
                % (TNPDEAL.szDealId(), account))

    AMB = amba.messages['xr']       # the INSERT_TRADE already mapped by base/trade_generic
    refs(AMB.TRADE.PRFNBR).PRFID = pf.Name()
    log.info('FXBookingPortfolio: deal %s booked into %s (Account(1)=%s)'
             % (TNPDEAL.szDealId(), pf.Name(), account))

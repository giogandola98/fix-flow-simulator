"""cancel_open_orders.py - closes every order still live on the FX market.

Author: GGIR

A test run that is interrupted, or one whose fills never came back because the FIX
session was down, leaves orders sitting active in PRIME. They are harmless but they make
the next run unreadable, so this clears the field first: it lists the live orders,
cancels them, and keeps going until none are left.

Cancelling needs the other side to answer. The provider is simulated, so the simulator
has to be running with a scenario that replies to an OrderCancelRequest - see the
`cancel-responder` scenario this script loads by itself. Without an answer the order sits
in PendingCancel, which is reported rather than hidden.

    set FAUSER=... & set FAPWD=...
    "<PRIME>\\CommonLib\\PythonLib3.12.7\\python.exe" cancel_open_orders.py
"""
import json
import sys
import os
import urllib.error
import urllib.request

sys.path.insert(0, r'E:\FrontArena\Front Arena\PRIME\2025.1')
import acm

API = 'http://localhost:8080/api/v1'
FA_HOST = 'chgvavfapi20:9000'
MARKET = 'FX_LINK'
SESSION_NAME = 'fxexecutor'
ROUNDS = 6

# The scenario that answers a cancel. It has to be armed once per cancel, like every
# other scenario here: an execution consumes one message and ends.
CANCEL_SCENARIO = '''# Author: GGIR
name: cancel-responder - answers an OrderCancelRequest with a Canceled report
version: '1.0'
sessionRef: fxexecutor
nodes:
  - id: start
    name: Start
    type: START
    config: {}
    onSuccess: expect-cancel
  - id: expect-cancel
    name: Waits for an OrderCancelRequest
    type: EXPECT_FIX
    config:
      msgType: F
    timeout: { value: 20, unit: SECONDS, onTimeout: FAIL }
    onSuccess: send-cancelled
    onTimeout: end-fail
  - id: send-cancelled
    name: ExecutionReport Canceled (150=4, 39=4)
    type: SEND_FIX
    config:
      msgType: '8'
      fields:
        - { tag: 37,  value: 'BNK-CXL-{{seq:orderid}}' }
        - { tag: 11,  value: '{{node:expect-cancel:tag11}}' }
        - { tag: 41,  value: '{{node:expect-cancel:tag41}}' }
        - { tag: 17,  value: 'EXE-{{seq:execid}}' }
        - { tag: 150, value: '4' }
        - { tag: 39,  value: '4' }
        - { tag: 1,   value: '{{node:expect-cancel:tag1}}' }
        - { tag: 55,  value: '{{node:expect-cancel:tag55}}' }
        - { tag: 54,  value: '{{node:expect-cancel:tag54}}' }
        - { tag: 38,  value: '{{node:expect-cancel:tag38}}' }
        - { tag: 151, value: '0' }
        - { tag: 14,  value: '0' }
        - { tag: 6,   value: '0' }
        - { tag: 60,  value: '{{nowdate:offset:+0s}}' }
    onSuccess: end-pass
    onFailure: end-fail
  - id: end-pass
    name: Pass
    type: END_PASS
    config: {}
  - id: end-fail
    name: Fail
    type: END_FAIL
    config: {}
edges:
  - { from: start, to: expect-cancel }
  - { from: expect-cancel, to: send-cancelled }
  - { from: send-cancelled, to: end-pass }
  - { from: expect-cancel, to: end-fail }
'''


def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(API + path, data=data, method=method,
                                 headers={'Content-Type': 'application/json'})
    raw = urllib.request.urlopen(req, timeout=25).read().decode()
    return json.loads(raw) if raw.strip() else {}


def sessionId():
    sessions = call('GET', '/sessions')
    sessions = sessions.get('content', sessions) if isinstance(sessions, dict) \
        else sessions
    for s in sessions:
        if s.get('name') == SESSION_NAME:
            return s['id']
    raise SystemExit('sessione %r assente nel simulatore' % SESSION_NAME)


def liveOrders():
    """Every own order still open, looked at from as wide a window as the filter allows.

    A default FOwnOrderFilter only looks at part of the day; ActFromAlways widens it, so
    an order left over from an earlier run is not missed just because of when it was
    entered.
    """
    acm.PollAllEvents()
    f = acm.FOwnOrderFilter()
    try:
        f.ActFromAlways(True)
        f.ActToOnwards(True)
    except Exception:
        pass
    orders = acm.Trading.GetOwnOrders(f) or []
    live = []
    for o in orders:
        try:
            if str(o.Status()) not in ('Deleted', 'Filled', 'Cancelled', 'Expired',
                                       'Rejected'):
                live.append(o)
        except Exception:
            pass
    return live


def main():
    p = os.environ['FAPWD']
    acm.Connect(FA_HOST, os.environ['FAUSER'], p, p, 'fxcancel', 0, 0, '')
    mp = acm.FMarketPlace[MARKET]
    if not mp.IsConnected():
        acm.FMarketService(mp).Connect(30000)
    if not mp.IsConnected():
        raise SystemExit('%s non connesso' % MARKET)

    session = sessionId()
    scenarioId = call('POST', '/scenarios', {'yamlDsl': CANCEL_SCENARIO})['id']
    try:
        for round_ in range(1, ROUNDS + 1):
            orders = liveOrders()
            print('giro %d: %d ordini ancora aperti' % (round_, len(orders)))
            if not orders:
                print('campo pulito')
                return 0
            for o in orders:
                try:
                    print('   %-8s %-18s qty=%s' % (o.Oid(), o.Status(), o.Quantity()))
                except Exception:
                    pass
                # One armed execution per cancel: an execution consumes one message.
                call('POST', '/scenarios/%s/execute' % scenarioId,
                     {'sessionId': session})
                acm.Sleep(1000)
                try:
                    acm.Trading.CancelOrder(o)
                except Exception as exc:
                    print('      non cancellabile: %s'
                          % str(exc).splitlines()[0][:70])
                for _ in range(6):
                    acm.PollAllEvents()
                    acm.Sleep(1000)
        left = liveOrders()
        print('')
        print('restano %d ordini aperti dopo %d giri' % (len(left), ROUNDS))
        return 1 if left else 0
    finally:
        try:
            call('DELETE', '/scenarios/%s' % scenarioId)
        except urllib.error.HTTPError:
            pass


if __name__ == '__main__':
    sys.exit(main())

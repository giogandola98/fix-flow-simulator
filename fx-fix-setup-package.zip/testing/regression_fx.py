"""regression_fx.py - end-to-end regression for the whole FX order flow.

Author: GGIR

Drives the chain from nothing for every instrument in scope - spot, forward outright,
NDF and swap, deliverable and not - plus the order types and the rejections that must
never reach the wire. For each case it loads the scenario into the simulator, arms it,
sends a real order from PRIME, and then checks BOTH sides: the message the simulator
received, and what was booked in Front Arena. It cleans up the scenarios it created.

It exists because every defect found in this flow was invisible from one side alone:
legs collapsing into one, quantity zero, a sell booked as a buy, a non-deliverable pair
booked as deliverable. Each is caught below, and so is the shape of every message.

Standard library only, plus acm - so it runs with PRIME's own interpreter:

    set FAUSER=... & set FAPWD=...
    "<PRIME>\\CommonLib\\PythonLib3.12.7\\python.exe" regression_fx.py

The simulator must be up on localhost:8080 with its FIX session connected to AMAS.

Cases carrying `known` are defects already reported and still open. They are run, and a
failure is counted separately so it does not drown the signal - but if one of them starts
PASSING that is reported too, because it means the marker should come off.

Exit code 0 when nothing fails unexpectedly, 1 otherwise.
"""
import io
import json
import os
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, r'E:\FrontArena\Front Arena\PRIME\2025.1')
import acm

API = 'http://localhost:8080/api/v1'
HERE = os.path.dirname(os.path.abspath(__file__))
SCENARIOS = os.path.join(HERE, '..', 'simulator', 'scenarios')
SINGLE_SCENARIO = os.path.join(SCENARIOS, '22-fx-single-order.yaml')
SWAP_SCENARIO = os.path.join(SCENARIOS, '21-fx-swap-multileg-capture.yaml')
AMEND_SCENARIO = os.path.join(SCENARIOS, '23-fx-order-amend.yaml')
CANCEL_SCENARIO = os.path.join(SCENARIOS, '24-fx-order-cancel.yaml')

FA_HOST = 'chgvavfapi20:9000'
MARKET = 'FX_LINK'
PORTFOLIO = 'FX_TRADING'
BOOKING_PORTFOLIO = 'FX_TRADING'
MARKET_ACCOUNT = 'Own'
QUANTITY = 1000000.0
SESSION_NAME = 'fxexecutor'
CONNECT_TIMEOUT_MS = 30000

FILL_TIMEOUT_S = 45
ENTER_TIMEOUT_S = 30
# How long to wait before declaring that a rejected order really did not reach the wire.
REJECT_SETTLE_S = 12

# The price written in both scenario files; each case substitutes its own and then
# asserts exactly what it substituted.
YAML_PX = '1.08500'
YAML_FAR_PX = '1.10341'

# A Friday, well clear of any spot date, so the value date is never a weekend.
VALUE_DATE = '20270430'
VALUE_DATE_ISO = '2027-04-30'
SWAP_NEAR_ISO = '2026-08-31'
SWAP_FAR_ISO = '2027-08-31'


def spot(name, side, **kw):
    """A single order on a currency pair order book. Everything defaults to a market
    order good for day, which is the shape the other cases vary from."""
    case = {'name': name, 'kind': 'single', 'instrument': 'EUR', 'currency': 'USD',
            'side': side, 'priceCondition': 'Unlimited', 'price': None,
            'validity': None, 'expiration': None, 'orderType': None,
            'triggerPrice': None, 'reference': None, 'px': '1.08500'}
    case.update(kw)
    return case


CASES = [
    # ---------------------------------------------------------------- spot
    spot('spot EUR/USD comprato', 'Buy',
         wire={55: ['EUR/USD'], 167: ['FXSPOT'], 15: ['USD'], 54: ['1'],
               40: ['1'], 59: ['0'], 63: ['0'], 64: None},
         books=[{'exact': 'EUR', 'sign': 1, 'price': 1.085}]),

    # A sell books on USD, a buy on EUR: Front Arena puts the spot on the instrument
    # of the currency being BOUGHT, so the pair's two sides land on two different
    # instruments. Observed, not assumed - the buy case above books on EUR.
    spot('spot EUR/USD venduto', 'Sell',
         wire={167: ['FXSPOT'], 54: ['2'], 63: ['0'], 64: None},
         books=[{'exact': 'USD', 'sign': -1, 'price': 1.085}]),

    # ------------------------------------------------- forward and NDF outright
    spot('forward EUR/USD comprato', 'Buy', reference=VALUE_DATE,
         wire={167: ['FXFWD'], 54: ['1'], 63: ['6'], 64: [VALUE_DATE], 120: None},
         books=[{'prefix': 'MF_FWRD_', 'date': VALUE_DATE, 'sign': 1,
                 'price': 1.085, 'valueDay': VALUE_DATE_ISO,
                 'settlementType': 'Physical Delivery'}]),

    spot('NDF USD/CNY comprato', 'Buy', instrument='USD', currency='CNY',
         reference=VALUE_DATE, px='7.10000',
         wire={55: ['USD/CNY'], 167: ['FXNDF'], 15: ['CNY'], 54: ['1'],
               63: ['6'], 64: [VALUE_DATE], 120: ['USD']},
         books=[{'prefix': 'MF_NDF_FWRD_', 'date': VALUE_DATE, 'sign': 1,
                 'price': 7.10, 'valueDay': VALUE_DATE_ISO,
                 'settlementType': 'Cash'}]),

    # ------------------------------------------------------------- order types
    spot('limite, good for day', 'Buy', priceCondition='Limited', price=1.05,
         wire={40: ['2'], 44: ['1.05'], 59: ['0']},
         books=[{'exact': 'EUR', 'sign': 1, 'price': 1.085}],
         known='il prezzo limite viene arrotondato a un decimale'),

    spot('good till date', 'Buy', validity='Till Time', expiration=VALUE_DATE_ISO,
         wire={59: ['6']},
         books=[{'exact': 'EUR', 'sign': 1, 'price': 1.085}]),

    spot('rifiuto: good till cancel', 'Buy', validity='Till Cancelled',
         reject='il GTC non e piu supportato su nessun ordine',
         forbiddenWire={59: '1'}),

    spot('rifiuto: at the opening', 'Buy', validity='Opening Auction',
         reject='un pricer FX non ha aste di apertura',
         forbiddenWire={59: '2'}),

    # PRIME offers it and lets it be entered. Without the check in AMAS it would reach
    # the provider as a plain market order, stripped of what made it a trailing stop.
    spot('rifiuto: trailing stop percentuale', 'Buy',
         orderType='Trailing Stop (Pct)',
         reject='il trailing sarebbe degradato a ordine a mercato'),

    # The swap leaves as one multileg order, so changing a leg after the fact means
    # nothing on the wire: cancel and send a new one.
    {'name': 'rifiuto: modifica di uno swap', 'kind': 'amend',
     'instrument': 'TEST FX SWAP', 'currency': 'USD', 'side': 'Buy',
     'priceCondition': 'Unlimited', 'price': None, 'validity': None,
     'expiration': None, 'orderType': None, 'triggerPrice': None,
     'reference': None, 'px': '1.08500', 'farPx': '1.10341',
     'amend': {'quantity': 750000.0},
     'rejectAmend': 'uno swap non e modificabile, si cancella e si rimanda'},

    spot('fill or kill', 'Buy', orderType='Fill or Kill (FOK)',
         wire={59: ['4']},
         books=[{'exact': 'EUR', 'sign': 1, 'price': 1.085}]),

    spot('fill and kill', 'Buy', orderType='Fill and Kill (IOC)',
         wire={59: ['3']},
         books=[{'exact': 'EUR', 'sign': 1, 'price': 1.085}]),

    # ------------------------------------------------------------------- stops
    # OrdType 3 and 4 come out of CASE_TriggerCondition_PriceCondition2OrdType: the
    # trigger decides stop or not, the price condition decides market or limit.
    spot('stop order', 'Buy', orderType='Trigger Price', triggerPrice=1.20,
         wire={40: ['3'], 99: ['1.2'], 59: ['0']},
         books=[{'exact': 'EUR', 'sign': 1, 'price': 1.085}]),

    spot('stop limit', 'Buy', orderType='Trigger Price', triggerPrice=1.20,
         priceCondition='Limited', price=1.19,
         wire={40: ['4'], 99: ['1.2']},
         books=[{'exact': 'EUR', 'sign': 1, 'price': 1.085}],
         known='il prezzo limite viene arrotondato a un decimale'),

    # ------------------------------------------------------------------ amends
    # An amend is legal only after the order has been acked: CLAUDE.md calls an amend
    # against an unacked order a fault on our side, so the scenario acks first and the
    # case waits for that before amending.
    spot('modifica accettata', 'Buy', kind='amend',
         priceCondition='Limited', price=1.05,
         amend={'quantity': 750000.0, 'price': 1.06},
         wire={35: ['D', 'G'], 38: ['1000000', '750000'], 41: None},
         books=[]),

    # ----------------------------------------------------------------- cancels
    # The same lifecycle on every shape. What is checked is both sides: an
    # OrderCancelRequest carrying OrigClOrdID(41) on the wire, and a booking portfolio
    # that stays EMPTY - a cancelled order that books a trade is the defect that no
    # amount of reading the FIX log would reveal.
    spot('cancel: spot EUR/USD', 'Buy', kind='cancel'),

    spot('cancel: forward EUR/USD', 'Buy', kind='cancel', reference=VALUE_DATE),

    spot('cancel: NDF USD/CNY', 'Buy', kind='cancel',
         instrument='USD', currency='CNY', reference=VALUE_DATE, px='7.10000'),

    {'name': 'cancel: swap EUR/USD', 'kind': 'cancel', 'entryMsgType': 'AB',
     'instrument': 'TEST FX SWAP', 'currency': 'USD', 'side': 'Buy',
     'priceCondition': 'Unlimited', 'price': None, 'validity': None,
     'expiration': None, 'orderType': None, 'triggerPrice': None,
     'reference': None, 'px': '1.08500', 'farPx': '1.10341'},

    {'name': 'cancel: swap USD/CNY (NDS)', 'kind': 'cancel', 'entryMsgType': 'AB',
     'instrument': 'TEST NDS USDCNY', 'currency': 'CNY', 'side': 'Buy',
     'priceCondition': 'Unlimited', 'price': None, 'validity': None,
     'expiration': None, 'orderType': None, 'triggerPrice': None,
     'reference': None, 'px': '7.10000', 'farPx': '7.24000'},

    # -------------------------------------------------------------- rejections
    # These must be stopped by AMAS before anything reaches the provider. The check is
    # that the simulator saw nothing: that is the contract in CLAUDE.md, "rejected
    # before they reach the wire".
    #
    # The third rejection, a pair with no deliverable leg at all (XERR ->
    # INVALID_FX_NO_SETTL_CCY), is NOT covered: no order book on this environment has
    # both currencies non-deliverable, so it cannot be provoked.
    spot('rifiuto: NDF senza value date', 'Buy',
         instrument='USD', currency='CNY', reference=None,
         reject='su una coppia non consegnabile lo spot non esiste'),

    spot('rifiuto: value date scritta male', 'Buy', reference='30042027',
         reject='30042027 e una data italiana, non YYYYMMDD'),

    # -------------------------------------------------------------------- swaps
    {'name': 'swap EUR/USD comprato', 'kind': 'multileg',
     'instrument': 'TEST FX SWAP', 'currency': 'USD', 'side': 'Buy',
     'priceCondition': 'Unlimited', 'price': None, 'validity': None,
     'expiration': None, 'orderType': None, 'reference': None,
     'px': '1.08500', 'farPx': '1.10341',
     'wire': {55: ['TESTFXSWAP'], 167: ['MLEG'], 54: ['1'], 555: ['2'],
              600: ['EUR/USD', 'EUR/USD'], 609: ['FXSPOT', 'FXFWD'],
              624: ['1', '2'], 588: ['20260831', '20270831'], 675: None},
     'books': [{'prefix': 'MF_FWRD_', 'date': '20260831', 'sign': 1, 'price': 1.085,
                'valueDay': SWAP_NEAR_ISO, 'settlementType': 'Physical Delivery'},
               {'prefix': 'MF_FWRD_', 'date': '20270831', 'sign': -1, 'price': 1.10341,
                'valueDay': SWAP_FAR_ISO, 'settlementType': 'Physical Delivery'}]},

    {'name': 'swap EUR/USD venduto', 'kind': 'multileg',
     'instrument': 'TEST FX SWAP', 'currency': 'USD', 'side': 'Sell',
     'priceCondition': 'Unlimited', 'price': None, 'validity': None,
     'expiration': None, 'orderType': None, 'reference': None,
     'px': '1.08500', 'farPx': '1.10341',
     'wire': {55: ['TESTFXSWAP'], 167: ['MLEG'], 54: ['2'],
              624: ['2', '1'], 675: None},
     'books': [{'prefix': 'MF_FWRD_', 'date': '20260831', 'sign': -1, 'price': 1.085,
                'valueDay': SWAP_NEAR_ISO, 'settlementType': 'Physical Delivery'},
               {'prefix': 'MF_FWRD_', 'date': '20270831', 'sign': 1, 'price': 1.10341,
                'valueDay': SWAP_FAR_ISO, 'settlementType': 'Physical Delivery'}]},

    {'name': 'swap USD/CNY comprato (NDS)', 'kind': 'multileg',
     'instrument': 'TEST NDS USDCNY', 'currency': 'CNY', 'side': 'Buy',
     'priceCondition': 'Unlimited', 'price': None, 'validity': None,
     'expiration': None, 'orderType': None, 'reference': None,
     'px': '7.10000', 'farPx': '7.24000',
     'wire': {55: ['TESTNDSUSDCNY'], 167: ['MLEG'], 54: ['1'],
              600: ['USD/CNY', 'USD/CNY'], 609: ['FXNDF', 'FXNDF'],
              624: ['1', '2'], 675: ['USD', 'USD']},
     'books': [{'prefix': 'MF_NDF_FWRD_', 'date': '20260831', 'sign': 1, 'price': 7.10,
                'valueDay': SWAP_NEAR_ISO, 'settlementType': 'Cash'},
               {'prefix': 'MF_NDF_FWRD_', 'date': '20270831', 'sign': -1, 'price': 7.24,
                'valueDay': SWAP_FAR_ISO, 'settlementType': 'Cash'}]},
]


# ------------------------------------------------------------------------ simulator
def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(API + path, data=data, method=method,
                                 headers={'Content-Type': 'application/json'})
    raw = urllib.request.urlopen(req, timeout=25).read().decode()
    return json.loads(raw) if raw.strip() else {}


def loadScenario(case):
    """POSTs a copy of the scenario with this case's prices, returning its id.

    A new scenario per case rather than an update: PUT answers 200 without persisting
    yamlDsl, which silently leaves the old body in place.
    """
    path = {'multileg': SWAP_SCENARIO,
            'amend': AMEND_SCENARIO,
            'cancel': CANCEL_SCENARIO}.get(case['kind'], SINGLE_SCENARIO)
    with open(path, encoding='utf-8') as f:
        yaml = f.read()
    if case.get('farPx'):
        yaml = yaml.replace("'%s'" % YAML_FAR_PX, "'%s'" % case['farPx'])
    yaml = yaml.replace("'%s'" % YAML_PX, "'%s'" % case['px'])
    # A swap enters as a NewOrderMultileg; everything else as a NewOrderSingle. It is
    # the only difference between the five shapes on the cancel path, so the message
    # type is substituted rather than kept in five near-identical files.
    if case['kind'] == 'cancel' and case.get('entryMsgType') == 'AB':
        yaml = yaml.replace('      msgType: D', '      msgType: AB', 1)
    # A spot carries neither SettlType nor SettlDate, so echoing them back produces
    # `63=|64=` - empty tags on the wire. They are harmless enough that the trade still
    # books, but an empty tag has no business in an example that goes into the
    # provider's specification, so on a spot the two echoes are removed outright.
    if not case.get('reference'):
        for tag in (63, 64):
            yaml = yaml.replace(
                "        - { tag: %d,  value: '{{node:expect-order:tag%d}}' }\n"
                % (tag, tag), '')
    return call('POST', '/scenarios', {'yamlDsl': yaml})['id']


def sessionId(name):
    """The UUID of the FIX session, looked up by its readable name.

    Arming from the API does nothing without it. ExecutionManager.start resolves the
    session as `sessionId != null ? sessionId : parseSessionRef(scenario)`, and
    parseSessionRef does UUID.fromString on the scenario's sessionRef - ours is the
    readable name, not a UUID, so it returns null and the execution runs with NO session
    bound, never seeing a message while still reporting RUNNING.
    """
    sessions = call('GET', '/sessions')
    sessions = sessions.get('content', sessions) if isinstance(sessions, dict) \
        else sessions
    for s in sessions:
        if s.get('name') == name:
            return s['id']
    raise SystemExit('sessione %r assente: %s' % (name, [s.get('name') for s in sessions]))


def requireLiveSession(session):
    """Refuses to start unless the simulator's FIX session is actually connected.

    Without this the whole suite fails case by case with 'nothing reached the
    simulator', which reads like a dozen unrelated defects. It is one: AMAS was
    restarted, the simulator is the initiator and does not always come back on its own,
    and PRIME only says so at the moment of sending - 'FIX disconnected from market'.
    One reconnect is attempted before giving up.
    """
    for attempt in (1, 2):
        status = call('GET', '/sessions/%s/status' % session)
        if status.get('connected'):
            return
        if attempt == 1:
            print('sessione FIX giu, riconnetto...')
            call('PUT', '/sessions/%s/connect' % session, {})
            acm.Sleep(10000)
    raise SystemExit('la sessione FIX del simulatore non si connette: '
                     'nessun ordine potrebbe arrivare')


def arm(scenarioId, session):
    return call('POST', '/scenarios/%s/execute' % scenarioId,
                {'sessionId': session})['executionId']


def cleanup(scenarioId, executionId):
    """Stops the execution, then removes the scenario.

    Stopping matters more than deleting. An execution outlives the scenario it came
    from, and one left waiting keeps answering: a run abandoned halfway leaves armed
    executions that reply to the NEXT run with THEIR prices, which is exactly how the
    NDS case came back filled at 1.08500 instead of 7.10. Deleting the scenario does
    not stop them.
    """
    for method, path in (('POST', '/executions/%s/stop' % executionId),
                         ('DELETE', '/scenarios/%s' % scenarioId)):
        try:
            call(method, path, {} if method == 'POST' else None)
        except urllib.error.HTTPError:
            pass


def executionMessages(executionId):
    try:
        r = call('GET', '/executions/%s/messages' % executionId)
    except urllib.error.HTTPError:
        return []
    return r.get('content', r) if isinstance(r, dict) else r


def rawText(message):
    """The FIX text of a message.

    The raw text and not the parsed `fields` map the API also returns: that map is flat,
    so every repeating group collapses and the legs are simply not in it.
    """
    if isinstance(message, str):
        return message
    value = message.get('rawFix')
    return value if isinstance(value, str) else ''


def fixTags(text, tag):
    """Every value of a tag, in order of appearance - legs included."""
    prefix = '%d=' % tag
    return [p[len(prefix):] for p in text.replace('\x01', '|').split('|')
            if p.startswith(prefix)]


def drainBuffer(session):
    """Consumes orders left parked on the session before the run starts.

    MessageBuffer keeps whatever no execution claimed for five minutes, and a freshly
    armed execution polls that buffer before listening for anything new. One stale order
    makes every case afterwards answer the PREVIOUS one.

    The drain scenario only waits and ends: it must not reply, or draining would book
    trades for orders nobody is testing. It eats both message types.
    """
    eaten = 0
    for msgType in ('D', 'AB'):
        yaml = ('# Author: GGIR\n'
                'name: drain %s - consumes one parked order and ends\n'
                "version: '1.0'\n"
                'sessionRef: %s\n'
                'nodes:\n'
                '  - id: start\n    name: Start\n    type: START\n'
                '    config: {}\n    onSuccess: eat\n'
                '  - id: eat\n    name: Eats a parked order\n'
                '    type: EXPECT_FIX\n    config:\n      msgType: %s\n'
                '    timeout: { value: 3, unit: SECONDS, onTimeout: FAIL }\n'
                '    onSuccess: done\n    onTimeout: empty\n'
                '  - id: done\n    name: Ate one\n    type: END_PASS\n    config: {}\n'
                '  - id: empty\n    name: Nothing left\n    type: END_FAIL\n'
                '    config: {}\n'
                'edges:\n'
                '  - { from: start, to: eat }\n'
                '  - { from: eat, to: done }\n'
                '  - { from: eat, to: empty }\n' % (msgType, SESSION_NAME, msgType))
        scenarioId = call('POST', '/scenarios', {'yamlDsl': yaml})['id']
        try:
            for _ in range(20):
                executionId = arm(scenarioId, session)
                acm.Sleep(4000)
                if not executionMessages(executionId):
                    break
                eaten += 1
        finally:
            try:
                call('DELETE', '/scenarios/%s' % scenarioId)
            except urllib.error.HTTPError:
                pass
    if eaten:
        print('(svuotati %d ordini rimasti parcheggiati sulla sessione)' % eaten)


# ---------------------------------------------------------------------------- PRIME
def connectFa():
    p = os.environ['FAPWD']
    acm.Connect(FA_HOST, os.environ['FAUSER'], p, p, 'fxregression', 0, 0, '')


def connectMarket():
    market = acm.FMarketPlace[MARKET]
    if market is None:
        raise SystemExit('mercato %s non trovato' % MARKET)
    if not market.IsConnected():
        acm.FMarketService(market).Connect(CONNECT_TIMEOUT_MS)
    if not market.IsConnected():
        raise SystemExit('%s non si connette: non si puo mandare nulla' % MARKET)


def orderBookOf(case):
    ins = acm.FInstrument[case['instrument']]
    if ins is None:
        raise SystemExit('strumento %r assente' % case['instrument'])
    for ob in ins.OrderBooks():
        mp = ob.MarketPlace()
        if (mp and mp.Name() == MARKET and ob.Currency()
                and ob.Currency().Name() == case['currency']):
            return ob
    raise SystemExit('nessun order book per %s su %s in %s'
                     % (case['instrument'], MARKET, case['currency']))


def buildOrder(case, book, sessionOut=None):
    """Builds the order. sessionOut, if given, receives the trading session.

    The session matters for the amend: the handler returned here is the one that SENDS
    the order, and mutating it afterwards is refused with "Not allowed in current order
    state". The order that can be changed is the LIVE one, which only the session
    knows - see amendLiveOrder.
    """
    session = acm.FTradingSession(
        acm.FTradingSessionCustomInterface(acm.FPhysicalPortfolio[PORTFOLIO]))
    if sessionOut is not None:
        sessionOut.append(session)
    order = session.CreateOrder(book)
    if order is None:
        raise SystemExit('CreateOrder ha restituito None su %s' % book.ExternalId())
    order.BuyOrSell(case['side'])
    order.Quantity(QUANTITY)
    order.PriceCondition(case['priceCondition'])
    if case.get('price') is not None:
        order.Price(float(case.get('price')))
    if case.get('validity'):
        order.ValidityCondition(case.get('validity'))
    if case.get('expiration'):
        order.ExpirationDate(case.get('expiration'))
    if case.get('orderType'):
        order.OrderType(case.get('orderType'))
    # A stop is not a TriggerCondition in ACM, whatever the DMC calls it: it is
    # OrderType 'Trigger Price' plus a TriggerPrice, and the price condition decides
    # between stop market and stop limit. TriggerCondition itself cannot be set at all
    # - every value, string or number, leaves it at 'None'.
    if case.get('triggerPrice') is not None:
        order.TriggerPrice(float(case.get('triggerPrice')))
    if case.get('reference'):
        order.Reference(case.get('reference'))
    # Mandatory: without it the order leaves with market account 0 and AMAS rejects it
    # with "Market Account 0 is not an allowed value".
    order.MarketAccount(MARKET_ACCOUNT)
    order.Account(PORTFOLIO)
    order.UserId(acm.User().Name())
    order.IsIndependentModifyEnabled(True)
    return order


def waitEnterable(book, order):
    """Waits until the order book actually accepts orders.

    Connecting the market is not enough and the stored TradingStatus has nothing to do
    with it: entry is refused with "Not allowed to enter orders in current order book
    state" until the book has been subscribed to and the market has answered. PRIME's
    own windows subscribe as a side effect of showing the book; a script has to ask.

    It is the order's own CanBeSent that is polled, and the subscription is taken on the
    ORDER BOOK. TradingInterface().Status().EnterOrder() looks like the same question
    but never turned true here, so asking the order directly is both simpler and the
    one that works.
    """
    try:
        book.Subscribe()
    except Exception:
        pass
    deadline = time.time() + ENTER_TIMEOUT_S
    while time.time() < deadline:
        try:
            if order.CanBeSent():
                return True
        except Exception:
            pass
        acm.PollAllEvents()
        acm.Sleep(1000)
    return False


def amendLiveOrder(session, changes):
    """Amends the order the session is holding, and returns the command text.

    Three paths were tried before this one, and the two obvious ones are wrong:

      - mutating the handler that sent the order is refused outright, "Not allowed to
        set TotalQuantity ... Not allowed in current order state";
      - CreateOrderCopy and CreateReplacementOrder both hand back a handler that sends
        a brand new NewOrderSingle(D), not a replace.

    session.Orders() returns the LIVE order. Changing that one and calling SendOrder
    makes PRIME issue a ModifyOrder - the command comes back named "ModifyOrder", not
    "SendOrder" - which is what becomes OrderCancelReplaceRequest(G) on the wire.
    """
    live = list(session.Orders())
    if not live:
        raise RuntimeError('la sessione non tiene nessun ordine vivo da modificare')
    order = live[-1]
    if 'quantity' in changes:
        order.Quantity(changes['quantity'])
    if 'price' in changes:
        order.Price(changes['price'])
    command = order.SendOrder()
    for _ in range(6):
        acm.PollAllEvents()
        acm.Sleep(1000)
    return str(command)


def sendOrder(order):
    """Sends and returns the command text; the caller decides what a refusal means.

    SendOrder does NOT raise on a refusal - it returns a command whose text carries the
    reason - and it is asynchronous: acm.Sleep pumps the state machine, time.sleep does
    not, so without it the order never leaves.
    """
    command = order.SendOrder()
    for _ in range(6):
        acm.Sleep(1000)
    return str(command)


def bookedTrades():
    """Everything currently in the booking portfolio, oldest first.

    The portfolio is emptied before every case, so whatever is in it belongs to the case
    being run. That is deliberate: measuring "what is new" by an oid high-water mark was
    fragile - it reported zero bookings while TAB was plainly creating them - and the
    question "how many trades are in the portfolio" has no such ambiguity.
    """
    # BOTH pumps are needed. PollAllEvents drives the market state machine - it is
    # what makes an order sendable - but a trade booked by TAB arrives as a DATABASE
    # change, and only PollAllDbEvents delivers those. Without it the portfolio keeps
    # answering with the contents this connection loaded at startup, which is how the
    # suite spent an afternoon reporting zero bookings while the log showed TAB
    # creating them.
    acm.PollAllEvents()
    acm.PollAllDbEvents()
    portfolio = acm.FPhysicalPortfolio[BOOKING_PORTFOLIO]
    trades = list(portfolio.Trades()) if portfolio else []
    return sorted(trades, key=lambda t: t.Oid())


def cleanPortfolio():
    """Empties the booking portfolio and removes the instruments the tests generated.

    Scoped to BOOKING_PORTFOLIO and to the MF_ instruments the handlers create per
    order: currency pairs, their order books, the swap instruments and every other piece
    of reference data are the ground the tests run on and are never touched.

    Trades go first - an instrument carrying trades cannot be deleted. A trade that
    refuses to go is set to Void, which is how Front Arena cancels an operation it
    cannot remove; the live object is edited, never a Clone, because committing a clone
    inserts a second trade instead of amending the first.
    """
    acm.PollAllEvents()
    deleted = voided = 0
    for t in bookedTrades():
        try:
            t.Delete()
            deleted += 1
        except Exception:
            try:
                t.Status('Void')
                t.Commit()
                voided += 1
            except Exception as exc:
                print('    trade %s non rimosso: %s'
                      % (t.Oid(), str(exc).splitlines()[0][:60]))
    gone = 0
    for ins in acm.FInstrument.Select("name like 'MF_*'"):
        # Only the ones nothing points at. A generated instrument still carrying trades
        # belongs to another portfolio and is none of this suite's business; trying
        # anyway floods the log with foreign-key failures from the database.
        try:
            if list(ins.Trades()):
                continue
            ins.Delete()
            gone += 1
        except Exception:
            pass
    left = len(bookedTrades())
    if deleted or voided or gone:
        print('    ripulito: %d trade cancellati, %d a Void, %d strumenti rimossi'
              % (deleted, voided, gone))
    if left:
        raise SystemExit('il portafoglio %s non si svuota: restano %d trade'
                         % (BOOKING_PORTFOLIO, left))


def waitForBooking(expected):
    deadline = time.time() + FILL_TIMEOUT_S
    while time.time() < deadline:
        trades = bookedTrades()
        if len(trades) >= expected:
            return trades
        acm.Sleep(2000)
    return bookedTrades()


# ----------------------------------------------------------------------- assertions
class Result(object):
    def __init__(self, case):
        self.case = case
        self.name = case['name']
        self.known = case.get('known')
        self.failures = []
        self.note = ''
        self.messages = []
        self.trades = []

    def record(self, messages, trades):
        """Keeps what actually crossed the wire, for the addendum.

        The raw FIX is stored, not a reconstruction: an example that was rebuilt from
        what the code was supposed to send would document the intention rather than the
        behaviour, and the two have differed more than once here.
        """
        self.messages = [(str(m.get('direction', '?')), rawText(m)) for m in messages
                         if rawText(m)]
        self.trades = [(t.Instrument().Name() if t.Instrument() else '?',
                        t.Quantity(), t.Price(), str(t.ValueDay()),
                        t.Instrument().SettlementType() if t.Instrument() else '')
                       for t in trades]

    def check(self, ok, what, got=None, want=None):
        if not ok:
            self.failures.append(what if want is None
                                 else '%s: atteso %r, ottenuto %r' % (what, want, got))

    @property
    def passed(self):
        return not self.failures


def ourMessage(messages, case):
    """The message this case's own order produced.

    A capture from the parked buffer looks perfectly valid and would be reported as a
    dozen field mismatches instead of the one thing that is wrong: somebody else's
    order.
    """
    wanted55 = case['wire'][55][0] if 55 in case['wire'] else None
    for m in messages:
        text = rawText(m)
        if '35=D' not in text and '35=AB' not in text:
            continue
        if wanted55 and fixTags(text, 55)[:1] != [wanted55]:
            continue
        if fixTags(text, 54)[:1] != case['wire'].get(54, fixTags(text, 54)[:1]):
            continue
        return text
    return None


def checkWire(result, case, messages):
    text = ourMessage(messages, case)
    if text is None:
        seen = [(fixTags(rawText(m), 55)[:1], fixTags(rawText(m), 54)[:1])
                for m in messages]
        result.check(False, 'nessun ordine nostro ricevuto dal simulatore; '
                            'catturati invece: %s' % (seen or 'nulla'))
        return
    for tag in sorted(case['wire']):
        expected = case['wire'][tag]
        got = fixTags(text, tag)
        if expected is None:
            result.check(got == [], 'tag %d non deve esserci' % tag, got, [])
        else:
            result.check(got == expected, 'tag %d' % tag, got, expected)


def checkBooking(result, case, trades):
    expected = case['books']
    result.check(len(trades) == len(expected), 'numero di trade bookati',
                 len(trades), len(expected))
    if len(trades) != len(expected):
        return

    for trade, want in zip(trades, expected):
        ins = trade.Instrument()
        name = ins.Name() if ins else '?'
        label = want.get('exact') or (want['prefix'] + '..._' + want['date'])

        if 'exact' in want:
            result.check(name == want['exact'], 'strumento', name, want['exact'])
        else:
            result.check(name.startswith(want['prefix']) and name.endswith(want['date']),
                         'strumento', name, label)
        result.check(trade.Quantity() == want['sign'] * QUANTITY,
                     '%s: quantita' % label, trade.Quantity(), want['sign'] * QUANTITY)
        result.check(abs(trade.Price() - want['price']) < 1e-9,
                     '%s: prezzo' % label, trade.Price(), want['price'])
        if 'valueDay' in want:
            result.check(str(trade.ValueDay()) == want['valueDay'],
                         '%s: value date' % label, str(trade.ValueDay()),
                         want['valueDay'])
        if 'settlementType' in want and ins:
            result.check(ins.SettlementType() == want['settlementType'],
                         '%s: tipo regolamento' % label, ins.SettlementType(),
                         want['settlementType'])

    if len(expected) == 2:
        # Both legs come from one order, so they must land on two DIFFERENT instruments
        # differing only by date: this is what failed when the name carried no date.
        names = [t.Instrument().Name() for t in trades if t.Instrument()]
        result.check(len(set(names)) == 2,
                     'le due gambe devono stare su strumenti distinti', names, '2 nomi')


# ---------------------------------------------------------------------------- driver
def runReject(case, session, result):
    """The order must not reach the provider. WHERE it is stopped does not matter.

    There are three places it can be stopped, and all three satisfy the contract:

      - PRIME refuses to set the value at all, because the DMC overlay removed it from
        the market capability. Earliest and cleanest.
      - PRIME refuses the send.
      - AMAS refuses it, and nothing goes on the wire.

    A fourth outcome is neither refusal nor failure: PRIME silently NORMALISES a value
    it no longer offers - setting a removed validity leaves the order at good-for-day
    rather than raising. The order then legitimately reaches the provider, but WITHOUT
    the forbidden value, which is what `forbiddenWire` checks. Treating that as a
    failure, as an earlier version did, would have been reporting the DMC working as if
    it were broken.
    """
    scenarioId = loadScenario(case)
    executionId = arm(scenarioId, session)
    try:
        acm.Sleep(1000)
        book = orderBookOf(case)
        try:
            order = buildOrder(case, book)
        except RuntimeError as exc:
            result.note = ('rifiutato da PRIME, che non accetta nemmeno il valore: %s'
                           % ' '.join(str(exc).split())[:80])
            return
        if not waitEnterable(book, order):
            result.check(False, 'order book %s non accetta ordini' % book.ExternalId())
            return

        text = sendOrder(order)
        if 'Error' in text:
            result.note = ('rifiutato prima del filo: %s'
                           % ' '.join(text.split())[-90:])
            return

        acm.Sleep(REJECT_SETTLE_S * 1000)
        messages = executionMessages(executionId)
        captured = [rawText(m) for m in messages
                    if '35=D' in rawText(m) or '35=AB' in rawText(m)]

        forbidden = case.get('forbiddenWire')
        if forbidden:
            if not captured:
                result.note = 'rifiutato da AMAS, niente sul filo'
            for tag in sorted(forbidden):
                bad = forbidden[tag]
                for text_ in captured:
                    got = fixTags(text_, tag)[:1]
                    result.check(got != [bad],
                                 'il valore vietato %d=%s non deve raggiungere il '
                                 'provider' % (tag, bad), got, 'diverso da %s' % bad)
            if captured:
                result.note = 'PRIME lo normalizza, sul filo non arriva il valore vietato'
        else:
            result.check(not captured,
                         'l ordine NON doveva raggiungere il filo (%s)' % case['reject'],
                         len(captured), 0)
            if not captured:
                result.note = 'rifiutato da AMAS, niente sul filo'
        result.record(messages, [])
    finally:
        cleanup(scenarioId, executionId)


def runAmend(case, session, result):
    """Enters an order, waits for the ack, then amends it.

    The wait for the ack is not politeness: without it the amend would race the
    original, and an amend against an unacked order is exactly what must never be sent.
    """
    scenarioId = loadScenario(case)
    executionId = arm(scenarioId, session)
    try:
        acm.Sleep(1000)
        book = orderBookOf(case)
        sessionOut = []
        order = buildOrder(case, book, sessionOut)
        if not waitEnterable(book, order):
            result.check(False, 'order book %s non accetta ordini' % book.ExternalId())
            return
        text = sendOrder(order)
        if 'Error' in text:
            result.check(False, 'SendOrder rifiutato: %s' % ' '.join(text.split()))
            return

        # Wait for the ack to have been answered before amending.
        deadline = time.time() + FILL_TIMEOUT_S
        while time.time() < deadline:
            if len([m for m in executionMessages(executionId)
                    if '35=8' in rawText(m)]) >= 1:
                break
            acm.Sleep(2000)

        try:
            amendText = amendLiveOrder(sessionOut[0], case['amend'])
        except RuntimeError as exc:
            # PRIME refuses the change outright - 'Not allowed in current order state'
            # on a swap. For a case that expects the amend to be refused this is the
            # answer; for one that expects it to work it is a failure.
            if 'rejectAmend' in case:
                result.note = ('rifiutato da PRIME: %s'
                               % ' '.join(str(exc).split())[:80])
            else:
                result.check(False, 'modifica rifiutata da PRIME: %s'
                             % ' '.join(str(exc).split())[:80])
            return
        acm.Sleep(REJECT_SETTLE_S * 1000)
        messages = executionMessages(executionId)
        sent = [rawText(m) for m in messages if '35=G' in rawText(m)]

        if 'rejectAmend' in case:
            result.check('Error' in amendText or not sent,
                         'la modifica NON doveva raggiungere il filo (%s)'
                         % case['rejectAmend'], len(sent), 0)
        else:
            result.check(len(sent) == 1, 'un OrderCancelReplaceRequest sul filo',
                         len(sent), 1)
            if sent:
                orig = fixTags(sent[0], 41)
                result.check(len(orig) == 1 and orig[0],
                             'OrigClOrdID(41) deve incatenare la modifica',
                             orig, 'presente')
                qty = fixTags(sent[0], 38)
                want = ('%g' % case['amend']['quantity'])
                result.check(qty[:1] == [want] or qty[:1] == [want + '.0'],
                             'la nuova quantita sul filo', qty[:1], want)
        result.record(messages, [])
    finally:
        cleanup(scenarioId, executionId)


def runCancel(case, session, result):
    """Enters an order, waits for the ack, cancels it, and checks nothing was booked."""
    scenarioId = loadScenario(case)
    executionId = arm(scenarioId, session)
    try:
        acm.Sleep(1000)
        book = orderBookOf(case)
        order = buildOrder(case, book)
        if not waitEnterable(book, order):
            result.check(False, 'order book %s non accetta ordini' % book.ExternalId())
            return
        text = sendOrder(order)
        if 'Error' in text:
            result.check(False, 'SendOrder rifiutato: %s' % ' '.join(text.split()))
            return

        # The cancel goes only after the provider has acked: cancelling something it has
        # not confirmed races its own acknowledgement.
        deadline = time.time() + FILL_TIMEOUT_S
        acked = False
        while time.time() < deadline:
            if [m for m in executionMessages(executionId) if '35=8' in rawText(m)]:
                acked = True
                break
            acm.Sleep(2000)
        result.check(acked, 'nessun ack ricevuto: non si puo cancellare')
        if not acked:
            return

        try:
            acm.Trading.CancelOrder(order)
        except Exception as exc:
            result.check(False, 'CancelOrder solleva: %s'
                         % str(exc).splitlines()[0][:80])
            return
        for _ in range(8):
            acm.PollAllEvents()
            acm.Sleep(1000)

        messages = executionMessages(executionId)
        sent = [rawText(m) for m in messages if '35=F' in rawText(m)]
        result.check(len(sent) == 1, 'un OrderCancelRequest sul filo', len(sent), 1)
        if sent:
            orig = fixTags(sent[0], 41)
            result.check(len(orig) == 1 and orig[0],
                         'OrigClOrdID(41) deve incatenare il cancel', orig, 'presente')

        acm.Sleep(5000)
        trades = bookedTrades()
        result.check(not trades,
                     'un ordine cancellato non deve bookare nulla',
                     [t.Instrument().Name() for t in trades if t.Instrument()], [])
        result.record(messages, trades)
    finally:
        cleanup(scenarioId, executionId)


def runOrder(case, session, result):
    scenarioId = loadScenario(case)
    executionId = arm(scenarioId, session)
    try:
        # Arm before sending, never after: an execution binds as it starts.
        acm.Sleep(1000)

        book = orderBookOf(case)
        order = buildOrder(case, book)
        if not waitEnterable(book, order):
            result.check(False, 'order book %s non accetta ordini' % book.ExternalId())
            return

        text = sendOrder(order)
        if 'Error' in text:
            result.check(False, 'SendOrder rifiutato: %s' % ' '.join(text.split()))
            return

        trades = waitForBooking(len(case['books']))
        messages = executionMessages(executionId)
        checkWire(result, case, messages)
        checkBooking(result, case, trades)
        result.record(messages, trades)
    finally:
        cleanup(scenarioId, executionId)


def runCase(case, session):
    result = Result(case)
    try:
        # Between cases as well as before the run: an order left parked by a case that
        # did not consume it is handed to the NEXT case's execution, which then checks
        # somebody else's message and answers it with the wrong scenario.
        drainBuffer(session)
        cleanPortfolio()
        if 'reject' in case:
            runReject(case, session, result)
        elif case['kind'] == 'amend':
            runAmend(case, session, result)
        elif case['kind'] == 'cancel':
            runCancel(case, session, result)
        else:
            runOrder(case, session, result)
    except SystemExit as exc:
        result.check(False, 'interrotto: %s' % exc)
    return result


def writeAddendum(results, path):
    """One file with every case that was actually exercised, to fold into the spec.

    Only cases that passed are written as examples. A failing case would document a
    defect as if it were the contract.
    """
    lines = []
    lines.append('FX order flow over FIX 5.0 SP2 - worked examples')
    lines.append('=' * 78)
    lines.append('')
    lines.append('Author: GGIR')
    lines.append('')
    lines.append('Every message below was captured on the wire between the AMAS FIX')
    lines.append('toolkit and the simulator standing in for the pricer, and every')
    lines.append('booking below is what Front Arena actually produced from it. Nothing')
    lines.append('here is reconstructed from what the code intends to send.')
    lines.append('')
    lines.append('The booking portfolio is emptied before each case, so the trades')
    lines.append('listed under a case are all the trades that case produced.')
    lines.append('')
    lines.append('SOH separators are shown as | for readability. Tags appear in')
    lines.append('numeric order, which is how the simulator stores a captured message,')
    lines.append('not in the order they travel on the wire.')
    lines.append('')

    ok = [r for r in results if r.passed and r.messages]
    rejected = [r for r in results if 'reject' in r.case and r.passed]
    lines.append('Cases: %d with traffic, %d refused before the wire.'
                 % (len(ok), len(rejected)))
    lines.append('')

    for r in ok:
        lines.append('')
        lines.append('-' * 78)
        lines.append(r.name.upper())
        lines.append('-' * 78)
        c = r.case
        lines.append('Order sent from PRIME: %s %s %s on %s'
                     % (c['side'], QUANTITY, c['instrument'], c['currency']))
        if c.get('reference'):
            lines.append('Value date typed in the order Reference field: %s'
                         % c['reference'])
        lines.append('')
        for direction, raw in r.messages:
            label = {'INBOUND': 'AMAS -> pricer', 'OUTBOUND': 'pricer -> AMAS'}.get(
                direction, direction)
            lines.append('  [%s]' % label)
            lines.append('  %s' % raw.replace(chr(1), '|'))
            lines.append('')
        lines.append('  Booked in Front Arena:')
        for name, qty, px, day, settl in r.trades:
            lines.append('    %-28s qty=%-14s price=%-10s value date=%s  %s'
                         % (name, qty, px, day, settl))
        lines.append('')

    if rejected:
        lines.append('')
        lines.append('=' * 78)
        lines.append('REFUSED BEFORE THE WIRE')
        lines.append('=' * 78)
        lines.append('')
        lines.append('These never become a FIX message at all. AMAS answers PRIME with')
        lines.append('the reason and nothing is sent to the pricer, which is the')
        lines.append('contract: an order type we do not support is never quietly turned')
        lines.append('into one we do.')
        lines.append('')
        for r in rejected:
            lines.append('  %-34s %s' % (r.name, r.case['reject']))
        lines.append('')

    io.open(path, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    print('')
    print('esempi scritti in %s' % path)


def main():
    connectFa()
    connectMarket()
    session = sessionId(SESSION_NAME)
    requireLiveSession(session)
    drainBuffer(session)

    print('=' * 74)
    print('Regressione FX - %d casi: spot, forward, NDF, swap, tipi e rifiuti'
          % len(CASES))
    print('=' * 74)

    results = []
    for case in CASES:
        print('')
        print('>>> %s' % case['name'])
        result = runCase(case, session)
        results.append(result)
        if result.passed:
            print('    PASSATO' + ('  (il difetto noto e sparito: togliere il marcatore)'
                                   if result.known else ''))
            if result.note:
                print('             %s' % result.note)
        else:
            for failure in result.failures:
                print('    FALLITO  %s' % failure)
            if result.known:
                print('    (difetto gia noto: %s)' % result.known)

    unexpected = [r for r in results if not r.passed and not r.known]
    expected = [r for r in results if not r.passed and r.known]
    fixed = [r for r in results if r.passed and r.known]

    print('')
    print('=' * 74)
    for r in results:
        if r.passed:
            label = 'RISOLTO' if r.known else 'PASSATO'
        else:
            label = 'NOTO' if r.known else 'FALLITO'
        print('%-8s %s' % (label, r.name))
    print('=' * 74)
    print('%d passati, %d falliti, %d fallimenti gia noti, %d difetti noti risolti'
          % (len(results) - len(unexpected) - len(expected), len(unexpected),
             len(expected), len(fixed)))

    writeAddendum(results, os.path.join(HERE, 'FX_FIX50SP2_worked_examples.txt'))
    return 1 if unexpected else 0


if __name__ == '__main__':
    sys.exit(main())

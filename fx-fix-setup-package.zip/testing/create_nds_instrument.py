"""create_nds_instrument.py - an FX swap on a non-deliverable pair, for testing.

Author: GGIR

Creates TEST NDS USDCNY, the twin of TEST FX SWAP on USD/CNY, plus its order book on
FX_LINK. It exists to exercise the NDS path end to end: CNY is flagged non-deliverable
in PRIME, so the order must go out with both legs FXNDF and LegSettlCurrency(675)=USD,
and both fills must book on MF_NDF_FWRD_ instruments settling in cash.

Run headless:

    set FAUSER=... & set FAPWD=...
    "<PRIME>\\CommonLib\\PythonLib3.12.7\\python.exe" create_nds_instrument.py

It is idempotent: an existing instrument or order book of the same name is left alone
and reported, never duplicated or overwritten.

The shape is copied from TEST FX SWAP rather than invented, because that instrument is
the one already proven to reach AMAS as InstrumentType 12 with a usable FXSWAP record.
The only deliberate differences are the currencies and the nominal.
"""
import sys
import os

sys.path.insert(0, r'E:\FrontArena\Front Arena\PRIME\2025.1')
import acm

TEMPLATE = 'TEST FX SWAP'
NAME = 'TEST NDS USDCNY'

# USD/CNY by ACI convention: USD is the base, CNY the price currency. The instrument
# currency is the QUOTE, and the other leg carries the base - that is how
# ADMtoTNPCustom._swapRecord tells them apart when it builds the A/B symbol.
BASE = 'USD'
QUOTE = 'CNY'
RATE = 7.10
BASE_NOMINAL = 1000000.0

ORDER_BOOK_MARKETPLACE = 'FX_LINK'


def out(*a):
    print(' '.join(str(x) for x in a))


def dropAliases(entity, what):
    """Clones carry the original's aliases, whose identities are already taken.

    Committing one straight away fails with "Cannot create entity InstrumentAlias
    ... Duplicate.". The alias is TAB's own bookkeeping and nothing in the flow this
    instrument is built for reads it: ADMtoTNPBase sends the order book's ADM_INSID as
    acmInstrument.Name(), and ADMtoTNPCustom looks the instrument back up by that name.
    So it is dropped rather than forged, and TAB is free to assign its own.
    """
    try:
        aliases = entity.Aliases()
    except Exception:
        return
    if aliases and aliases.Size():
        out('   %s: rimossi %d alias ereditati dal clone' % (what, aliases.Size()))
        aliases.Clear()


def connect():
    p = os.environ['FAPWD']
    acm.Connect('chgvavfapi20:9000', os.environ['FAUSER'], p, p, 'ndscreate', 0, 0, '')


def createInstrument():
    existing = acm.FInstrument[NAME]
    if existing:
        out('strumento %s: esiste gia, lasciato com e' % NAME)
        return existing

    template = acm.FInstrument[TEMPLATE]
    if not template:
        raise SystemExit('modello %s non trovato' % TEMPLATE)

    ins = template.Clone()
    dropAliases(ins, 'strumento')
    ins.Name(NAME)
    ins.Currency(acm.FCurrency[QUOTE])
    ins.ContractSize(BASE_NOMINAL * RATE)

    # Leg 0 is the quote leg and leg 1 the base leg, as on the template: leg 0 carries
    # the instrument currency and the unit nominal factor, leg 1 the other currency and
    # the factor that converts it. The dates are left exactly as the template has them,
    # so near and far match the swap already in use and the two tests are comparable.
    legs = list(ins.Legs())
    if len(legs) != 2:
        raise SystemExit('il modello ha %d gambe, ne servono 2' % len(legs))
    legs[0].Currency(acm.FCurrency[QUOTE])
    legs[0].NominalFactor(1.0)
    legs[1].Currency(acm.FCurrency[BASE])
    legs[1].NominalFactor(1.0 / RATE)

    out('creo strumento %s: %s/%s, %s -> %s, nominale %s %s'
        % (NAME, BASE, QUOTE, legs[0].StartDate(), legs[0].EndDate(),
           BASE_NOMINAL, BASE))
    ins.Commit()
    return acm.FInstrument[NAME]


def createOrderBook(ins):
    existing = acm.FOrderBook.Select01("instrument='%s'" % NAME, None)
    if existing:
        out('order book %s: esiste gia, lasciato com e' % NAME)
        return existing

    template = acm.FOrderBook.Select01("instrument='%s'" % TEMPLATE, None)
    if not template:
        raise SystemExit('order book modello di %s non trovato' % TEMPLATE)

    ob = template.Clone()
    dropAliases(ob, 'order book')
    ob.Name(NAME)
    ob.Instrument(ins)
    ob.Currency(acm.FCurrency[QUOTE])
    ob.MarketPlace(acm.FMarketPlace[ORDER_BOOK_MARKETPLACE])

    # Same shape as the template's own id: the type prefix, the instrument name with
    # its separators stripped, then the trading currency. AMAS matches order books on
    # this, so a made-up format would simply not be found.
    ob.ExternalId('16%s%s' % (NAME.replace(' ', ''), QUOTE))

    out('creo order book %s su %s, ExternalId %s'
        % (NAME, ORDER_BOOK_MARKETPLACE, ob.ExternalId()))
    ob.Commit()
    return acm.FOrderBook.Select01("instrument='%s'" % NAME, None)


def report(ins, ob):
    out('')
    out('--- verifica ---')
    legs = list(ins.Legs())
    out('strumento  %s  tipo=%s  ccy=%s  contractSize=%s'
        % (ins.Name(), ins.InsType(), ins.Currency().Name(), ins.ContractSize()))
    for i, leg in enumerate(legs):
        out('   gamba %d  %s  factor=%s  %s -> %s'
            % (i, leg.Currency().Name(), leg.NominalFactor(),
               leg.StartDate(), leg.EndDate()))
    out('order book %s  mercato=%s  ccy=%s  ExternalId=%s'
        % (ob.Name(), ob.MarketPlace().Name(), ob.Currency().Name(), ob.ExternalId()))

    # The pair's own order book has to exist, or the leg cannot be resolved on the way
    # back and the settlement currency cannot be read on the way out.
    pair = acm.FOrderBook.Select01(
        "instrument='%s' and currency='%s'" % (BASE, QUOTE), None)
    out('order book della coppia %s/%s: %s'
        % (BASE, QUOTE, pair.Name() if pair else 'ASSENTE - il test non passerebbe'))


if __name__ == '__main__':
    connect()
    instrument = createInstrument()
    orderBook = createOrderBook(instrument)
    report(instrument, orderBook)

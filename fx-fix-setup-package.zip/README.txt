FX FIX integration - reproducing the setup
=========================================

Author: GGIR

What is in here, and where each piece belongs.

amas/Customised/
    Copy into <AMAS_INSTALL_ROOT>\Customised. That folder is the only place AMAS loads
    customisations from. Restart the AMAS service afterwards: the map files are compiled
    at startup, and so is the DMC overlay.

    customisedInclude.map   the whole order flow: SecurityType per instrument, the NDF
                            settlement currency, the value date, the FX swap legs on the
                            way out and the leg side and settlement date on the way back,
                            and every order type refused before the wire.
    customisedFunctions.map  getFXSettlementCurrency().
    DMC_FXFIX.xml           what PRIME is allowed to offer in its order entry. It must
                            also be listed in
                            Modules\DMCEnricher\Parameters\XmlAMASDescriptionFile.

tab/custom/
    Copy into <TAB_ROOT>\Msrv\python\custom. Restart the TAB service.

    ADMtoTNPCustom.py       ships the NDF settlement currency, the option record and the
                            FX swap record on the order book as it goes to AMAS.
    FXForwardInstrument.py  moves a forward, an NDF or a swap leg onto its own generated
                            instrument, MF_FWRD_<OrderID>_<YYYYMMDD>.
    FXBookingPortfolio.py   books into the portfolio named by Account(1).
    FXOptionInstrument.py   the same idea for options.

registry/
    Two settings the flow depends on. Import them, then restart AMAS.

    dmc_capability.reg              switches the DMC on for the market.
    order_reference_mapping.reg     blanks MI\Parameters\MapTNPReference so the order
                                    Reference field is free to carry the value date.
                                    Without this the value date lands in Text(58).

testing/
    regression_fx.py         the whole suite: spot, forward, NDF, swap, NDS, order types,
                             stop orders, amend, cancel on every shape, and the orders
                             that must be refused before reaching the wire. It empties
                             the booking portfolio before each case, checks both the wire
                             and the booking, and writes the worked examples file.
    create_nds_instrument.py builds TEST NDS USDCNY, the swap on a non-deliverable pair
                             the NDS cases need. Idempotent.
    cancel_open_orders.py    closes orders left live by an interrupted run.
    scenarios/               the simulator scenarios the suite loads by itself.
    FX_FIX50SP2_worked_examples.txt
                             every message captured on the wire and every booking it
                             produced, to fold into the provider specification.

Step by step
------------

Prerequisites: an AMAS installation with the FIX toolkit, a TAB installation, PRIME with
its currency pairs and order books already created, and Java 21 for the simulator
(github.com/giogandola98/fix-flow-simulator, tag v0.5.0-beta or later).

 1. Stop the AMAS and TAB services.

 2. Copy amas/Customised/*   ->  <AMAS_INSTALL_ROOT>\Customised
    Copy tab/custom/*        ->  <TAB_ROOT>\Msrv\python\custom

    Never edit these in the installation. They are deployed from the repository, and a
    change made in place is invisible to it and lost at the next deployment.

 3. Add DMC_FXFIX.xml to the enricher's file list:
    Modules\DMCEnricher\Parameters\XmlAMASDescriptionFile
    It is MERGED onto FIS's DMC_FIXTK2.xml, which must not be modified.

 4. Import registry/*.reg, then start AMAS.

    Watch the startup log. A map that does not compile stops the service, and the error
    names the symbol: "No such field (...)" means a variable used before assignment,
    "syntax error at ..." usually means an operator the map language does not have -
    there is no >= and no <=.

 5. Start TAB. It should log "TAB: Subscribing to MCDEAL".

 6. Start the simulator and connect its FIX session:

        java -jar fix-flow-api-*.jar
        curl -X PUT http://localhost:8080/api/v1/sessions/<id>/connect

    The session is an INITIATOR pointing at AMAS. After an AMAS restart it does not
    always come back on its own, and PRIME only reports it at the moment of sending -
    "FIX disconnected from market".

 7. Create the test instruments in PRIME. TEST FX SWAP has to exist as an FxSwap with
    two fixed legs and an order book on the market; then:

        "<PRIME>\CommonLib\PythonLib3.12.7\python.exe" create_nds_instrument.py

    which clones it onto USD/CNY for the non-deliverable cases.

 8. Restart TAB once more so the new order books reach AMAS. Look for
    "ADMtoTNPCustom: swap TEST NDS USDCNY -> 2026083120270831USD/CNY".

 9. Run the suite:

        set FAUSER=<user>
        set FAPWD=<password>
        "<PRIME>\CommonLib\PythonLib3.12.7\python.exe" regression_fx.py

    It needs PRIME's own interpreter - acm comes from there. It loads its own scenarios,
    empties the booking portfolio before each case, and writes the worked examples file
    at the end. Exit code 0 means nothing failed unexpectedly.

If a run is interrupted, cancel_open_orders.py closes whatever it left live before the
next one.

Three things about the environment that cost hours to find
----------------------------------------------------------

Arming a scenario from the REST API needs the session id in the request body.
ExecutionManager.start falls back to UUID.fromString(scenario.sessionRef), and a
readable name is not a UUID, so it silently binds to NO session: the execution reports
RUNNING and never receives anything.

ExecIDs must be unique. AMAS deduplicates on ExecID(17) and answers a repeat with
DontKnowTrade(35=Q), dropping the execution without booking anything and without an
error anywhere. The scenarios use a uuid rather than a counter for exactly this reason,
and the same requirement applies to the real provider.

A headless order needs OrderBook.Subscribe(). Until the market has answered the
subscription, entry is refused with "Not allowed to enter orders in current order book
state", whatever the stored TradingStatus says. PRIME's own windows subscribe as a side
effect of displaying the book; a script has to ask.

And one about the ACM API: the handler that SENDS an order and the order that is LIVE
are different objects. Amending means changing the one in session.Orders() - mutating
the sender is refused, and CreateOrderCopy or CreateReplacementOrder both send a new
order instead of a replace.

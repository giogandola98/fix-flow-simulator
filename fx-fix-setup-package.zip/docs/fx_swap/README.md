# FX Swap — how the two-legged order is sent

Author: GGIR

Written on 28/08/2026. Answers the question that was left open: *how to send linked
orders to AMAS*.

## The answer

**Two orders are not linked: a `NewOrderMultileg` is sent, and AMAS already knows how to
build it.** The installed and active `FIXOrder` flow contains everything needed to build
the `NoLegs` group. There is nothing to obtain and nothing to switch on.

The **`FIXCommon/FIXFXSwapMultiLegOrder`** package — the layer **specific to FX swaps**,
which among other things split the ExecutionReport into two MCDEALs — has been
**discontinued by Front Arena** and can no longer be obtained. Only its overlay
`FIXTK/FXSwapMultileg` is left in the installation, made of empty placeholders and by now
**dead code**: nothing calls its `_PP_*` any more.

What is lost with it is the **return leg**, not the outbound one. See "What is missing".

## Outbound: everything is there

`AIF/Packages/FIXCommon/FIXOrder/FIXOrderCommon.map`, line 447:

```
FUNCTION MAP_InstrumentDataMultileg()
    ...
    for (f_fdbLegEntry = strategyLegsFdb.getFirst("HeadOrderBookId", FSMOrderBookId); ...)
        LegSide[i]       selection(f_fdbLegEntry.Side1, TNP_BID, 1, TNP_ASK, 2)
        LegRatioQty[i]   f_fdbLegEntry.Ratio
        LegSymbol[i]     ifexist(f_fdbLegOrderbook.MarketInstrumentTradingId, "N/A")
        LegCFICode[i]    ifexist(f_fdbLegOrderbook.CFICode)
        ...
    NoLegs   i
```

And the state machine `FIXOrderFsm.xml` already routes `NewOrderMultileg`,
`NewOrderMultileg_modify` and `MultilegOrderCancelReplace`: new, amend and cancel of the
multileg are covered.

The customisation point for us is already there: `_CM_FC_MAP_InstrumentDataMultileg` to
replace the body, with a `_CM_FA_MAP_InstrumentDataMultileg` in append left commented out
in the core.

## Where the legs come from

From PRIME, on the order book record, in TNP. The loading is in
`AMASGeneral/OrderBooks/generalOrderBook_Functions.map` line 549:

```
TNPORDERBOOK.TNPINSTRUMENTOPTION[0].TNPOPTIONCOMBOLEG[i]
    .szLegOrderBookId        ->  strategyLegsFdb.LegOrderBookId
    .TNPRATIO.dRatio         ->  strategyLegsFdb.Ratio
    .dwBidOrAskIfBuy         ->  strategyLegsFdb.Side1
    .dwBidOrAskIfSell        ->  strategyLegsFdb.Side2
    .TNPPRICE.dPrice         ->  strategyLegsFdb.strike
```

keyed on `HeadOrderBookId` + `LegOrderBookId`. The name `TNPINSTRUMENTOPTION` is
misleading: it is the generic container for the legs of a combination, not something
specific to options.

So the chain is:

```
combination order book in PRIME  ->  TNPOPTIONCOMBOLEG  ->  strategyLegsFdb
                                 ->  NoLegs of the NewOrderMultileg
```

`Ratio` is an **integer** (`IS_INT` in the `strategyLegsFdb.xml` schema): near and far are
expressed as +1 / -1. It is also the answer to the problem hit when trying by hand — *the
combination has no weights*: the weight is `FCombInstrMap.Weight` on the PRIME side, and
without it the legs arrive with ratio 0.

## What is missing, and is ours to write

With the FX package discontinued, **the return leg is not covered**: nothing splits the
multileg `ExecutionReport` into the two MCDEALs, one per leg. It has to be written in our
customisations, on the `_CM_` hooks we already use for the ER -> MCDEAL path.

It is much smaller work than the whole flow, and it is also the only part where the
package was really needed: the outbound leg is handled by the generic flow.

## Order types accepted on a swap

Decided with the user on 28/08/2026 and implemented in `customisedInclude.map`:

- **entry**: market and limit orders, good for day and good till date. Rejected are GTC,
  FOK, FAK, the auction validities and the trigger on a reference price
  (`INVALID_FX_SWAP_ORDERTYPE`, -102);
- **amend**: always rejected on a swap order book (`INVALID_FX_SWAP_MODIFY`, -107). The
  two legs leave as a single multileg order, so changing one after the fact has no
  meaning on the wire: cancel and send a new one;
- **cancel**: allowed.

The rejected conditions are exactly those `MAP_TimeInForce` turns into something other
than GFD or GTD (`FIXOrderCommon.map:683`), read from the same place the core reads them,
so the check agrees with what would actually go on the wire.

## What is NOT the way

The TNP records `RTY_LINKEDORDER*` exist in `_TnpMaster.py` but are referenced in **zero**
AMAS maps. Linking two single orders is not the intended model and would have no mapping
towards FIX.

## The PRIME side: a native FX swap order

**PRIME builds the two-legged swap order itself.** No combination order book and no
linking of two single orders:

```python
session = acm.FTradingSession(acm.FTradingSessionCustomInterface(portfolio))
handler = acm.Trading.CreateFxSwapOrder(session, marketPlace)
near    = acm.Trading.CreateFxSwapNearLeg(handler, nearValueDate)
far     = acm.Trading.CreateFxSwapFarLeg(handler, farValueDate)
```

`CreateFxSwapOrder` returns an `FOrderHandler` whose `OrderProcessType` is `'FX Swap'` -
it is the **order process type** that was being looked for. Verified: both legs come back
with `OrderProcessType = 'FX Swap'` and `IsPartOfOrderProcessTypeOrder = True`.

Each leg is itself an `FOrderHandler`, that is a **complete order**: `Quantity`, `Price`,
`PriceCondition`, `BuyOrSell`, `Account`, `MarketAccount`, `ExpirationDate`, plus
`SendOrder` and `Validate`. That is what satisfies the requirement that each leg carry
all the financial data, the same as a single order.

And above all **each leg takes its own value date** as an argument.

`developments/fx_swap/build_fx_swap_order.py` builds one and prints its structure without
sending it.

### Why the combination order book was abandoned

It was built and tested on 28/08/2026: an `FCombination` in USD with two `FCombInstrMap`
legs of weight +1 and -1, plus a head order book on FX_LINK. It works as ADS reference
data, but it is the wrong model for an FX swap, for two reasons.

**It cannot express two value dates.** `strategyLegsFdb` is keyed on
(`HeadOrderBookId`, `LegOrderBookId`), and the two legs of an FX swap are the same pair on
the same order book, differing only by value date: they would collide on a single row.

**It cannot be created on the fly.** AMAS learns order books from TAB, which reads the
ADS; an infant object is not in the ADS, so it can neither reach `strategyLegsFdb` nor be
referenced by an order. It would have to be committed, and TAB only synchronises at
startup.

The test objects were deleted; `FCombination` and `FCombInstrMap` are back to zero
records.

## The experiment of 28/08/2026, and what it settled

The swap order was built in PRIME with the native process type and sent. **One single
message went out**, and it was not a multileg:

```
35=D  11=FXL260828013959  55=EUR/USD  38=1000000.0  40=1  54=1  59=0
63=0  167=FXSPOT  115=USD  528=A
```

A `NewOrderSingle` mapped as a **spot**: `63=0` Regular, `167=FXSPOT`, no `64` SettlDate,
no legs. The two value dates and the swap structure did not survive. No second message
followed.

**What this settles:** AMAS decides between multileg and single by looking at the **order
book**, not at the order. `MAP_InstrumentDataMultileg` is driven by `strategyLegsFdb`,
which is fed from the combination legs of the order book; ours is a plain currency order
book with no legs, so the state machine takes the single-order path and the process type
of the order is simply not consulted.

So PRIME's native FX swap order is the right way to **build** the two legs - it is the
only construct that carries a value date per leg - but on its own it does not reach the
wire as a swap.

### The fork this opens

1. **Combination order book after all.** It is what switches the multileg path on, but it
   brings back the two problems already measured: `strategyLegsFdb` is keyed on
   (`HeadOrderBookId`, `LegOrderBookId`) so two legs on the same pair collide on one row,
   and it has to be committed because AMAS learns order books from TAB reading the ADS.
2. **Carry the legs ourselves.** Write `_CM_FC_MAP_InstrumentDataMultileg` to build the
   `NoLegs` group from something other than `strategyLegsFdb` - for instance from the
   order book blob, which is already the channel used for the NDF settlement currency and
   for the option record. It would also need the near/far value dates, and the Reference
   field carries only one.

Which of the two depends on what the pricer accepts, and its specification does not cover
swaps at all.

## Regression — `regression_fx_swap.py`

The round trip is covered end to end by `regression_fx_swap.py`. It loads the scenario
into the simulator itself, arms it, sends a real order from PRIME and then checks **both
sides**: the `NewOrderMultileg` the simulator received, and the trades that came out in
Front Arena. It cleans up after itself and exits non-zero on the first failure, so it can
be wired into a build.

```
set FAUSER=ARENASYS & set FAPWD=...
"E:\FrontArena\Front Arena\CommonLib\PythonLib3.12.7\python.exe" regression_fx_swap.py
```

Three cases, all passing as of 28/08/2026:

| Case | Wire | Booking |
|------|------|---------|
| EUR/USD bought | `609=FXSPOT/FXFWD`, `624=1/2`, no `675` | `MF_FWRD_*_20260831` +1M, `*_20270831` −1M |
| EUR/USD sold | `624=2/1` | signs reversed |
| USD/CNY bought (NDS) | `609=FXNDF/FXNDF`, `675=USD/USD` | `MF_NDF_FWRD_*`, settlement Cash |

The NDS case needs `TEST NDS USDCNY`, which `create_nds_instrument.py` builds from
`TEST FX SWAP`. It is idempotent and safe to re-run.

Three things about the environment cost hours to find and are worth knowing before
touching this:

- **Arming from the REST API needs the session id in the body.** `ExecutionManager.start`
  falls back to `UUID.fromString(scenario.sessionRef)`, and our `sessionRef` is the
  readable name `fxexecutor`, not a UUID — so it resolves to *no session* and the
  execution never receives anything while still reporting `RUNNING`. The UI passes the
  id; the script now looks it up by name and does the same.
- **Unmatched orders are parked for five minutes.** `MessageBuffer` keeps whatever no
  execution claimed, and a freshly armed execution polls that buffer first. One stale
  order makes every case afterwards answer the *previous* one. The script drains the
  buffer before it starts.
- **A headless order needs `OrderBook.Subscribe()`.** Without it entry is refused with
  *"Not allowed to enter orders in current order book state"*, whatever the stored
  `TradingStatus` says — PRIME's own windows subscribe as a side effect of displaying
  the book, a script has to ask.

## Next steps

1. The PRIME interface for spread quoting.
2. Amend on a swap: not supported today, `INVALID_FX_SWAP_MODIFY`. Cancel works.
3. Partial fills on a multileg: only the full fill is covered.

## To be confirmed with the provider

`documentazione/FIX50SP2_FX_OrderEntry_EN.pdf` covers **Spot, Forward Outright and NDF**:
the swap is not there. Before building, it must be confirmed that the pricer accepts
`NewOrderMultileg`, with which `LegSymbol` and which convention on sides and ratios.

The requirement given by the user is that **each leg carries all the financial data, the
same information as a single order**, in standard FIX 5.0 SP2. That is now what
`_CM_FC_MAP_InstrumentDataMultileg` emits: `LegSymbol`, `LegSecurityType`, `LegRatioQty`,
`LegSide`, `LegCurrency`, `LegQty`, `LegSettlType`, `LegSettlDate`, and on an NDS
`LegSettlCurrency`. The stock macro emitted far less — no `LegSettlDate`, no `LegQty` and
no per-leg price.

Two extrapolations in there are **not** confirmed by the provider spec, which does not
cover swaps at all, and both belong to open point 8:

- `LegSecurityType=FXNDF` plus `LegSettlCurrency(675)` on a non-deliverable pair. It is
  the per-leg reading of the single-order rule (`FXNDF` + `SettlCurrency(120)`), and 675
  sits in `LegOrdGrp` right after `LegSettlDate` in both the AMAS and the QuickFIX/J
  FIX50SP2 dictionaries.
- `FXSPOT` on the near leg of a deliverable swap. Both legs travel with an explicit
  `SettlDate` and `SettlType=6`, so calling the near one a spot is a convention rather
  than a description. The constants at the top of `customisedInclude.map` exist to be
  changed once the provider says.

# CLAUDE.md — FX FIX Integration

## What this project is

An integration layer that carries **FX order flow from Front Arena PRIME to an external
pricing/execution provider** over **FIX 5.0 SP2 (session layer FIXT.1.1)**.

PRIME does not speak FIX itself: it talks to an **AMAS service** that performs the TNP ↔ FIX
translation. All of our AMAS work is customisation of that service.

The provider **does not exist yet**. Until it does, the far side of the wire is **simulated**
with `fix-flow-simulator` (see [Simulator](#simulator)). Every behaviour we build must be
demonstrable end-to-end against that simulator — a feature with no simulator scenario is not done.

```
                 orders / amends / cancels
PRIME ──TNP──> AMAS service (FIX Toolkit 2) ──FIX 5.0 SP2──> Provider "pricer"   [SIMULATED]
      <──TNP──                              <──FIX 5.0 SP2──
                 acks / partial fills / fills / rejects
```

## Status

**Read [`HANDOVER.md`](HANDOVER.md) first.** It has where the work actually stands, what is
deployed on this machine, and what to do next. This file stays the source of truth for *scope
and conventions*; `HANDOVER.md` is the source of truth for *state*.

Short version: currency pairs are done (1656 in PRIME, NDF flagged). The NDF/settlement-currency
chain from PRIME to AMAS via TAB is written and deployed, and is being verified right now. The
order value date is designed but blocked. No FIX order flow yet, and the simulator has no
scenarios.

## First task — currency pairs in PRIME — DONE

*(Kept for the reasoning. 1656 pairs exist in PRIME; see `developments/currency_pairs/README.md`.
Point 3, the AMBA export, is still open.)*

**PRIME currently has no currency pairs.** Nothing else can be traded, priced or sent over FIX
until they exist, so this is the starting point of the project.

1. **Create the currency pairs in PRIME.** There must be a currency pair for **every pair of
   currencies** in scope — not just the majors, not just the ones needed for the first test.
2. **Flag the non-deliverable pairs.** NDF pairs must be marked as such. *The location of this
   setting is not known yet* — find it in the FA docs / PRIME configuration before creating the
   pairs, so they are created right the first time rather than patched afterwards.
3. **Export them to AMBA through PRIME's integrated Python editor.** The export script is the
   deliverable, not the clicking: it is what makes the setup reproducible on another environment.
   Script and exported output both go under `developments/` (see
   [Reproducibility](#reproducibility--developments)) — `developments/amba_configs/` is the
   destination for the AMBA side.

Do the creation itself scripted where PRIME allows it. A pair list that only exists because someone
clicked through a UI is not reproducible and does not satisfy point 3.

Before starting, settle: which currency universe is in scope, the quotation convention
(market-standard direction, e.g. `EUR/USD` not `USD/EUR`), and the naming that must line up with the
`CCY1/CCY2` symbol mapping already present in `customisedInclude.map`.

## Scope

### Instruments (nothing else)

- FX Spot
- FX Forward
- FX Vanilla Option
- FX Swap

#### FX Forward order entry in PRIME — known problem

Forwards are entered **exactly like spots**: an order book of one currency against another.
The only difference is a **manually set value date**.

**There is no value-date field in PRIME's order entry.** Finding how to carry it is an open piece
of work, not a detail to hand-wave:

- decide *where* the user types it (existing field repurposed, additional column, order-book
  attribute, extra info field — check what the AMAS/TAB docs allow);
- decide *how* it reaches AMAS and then FIX (`SettlDate(64)` and/or `SettlType(63)=B` forward);
- make it impossible to send a forward without a value date, and impossible to attach one to a spot
  by accident.

Do not invent a mechanism silently — investigate against the FA docs, then propose the options with
their trade-offs before implementing.

**Booking instrument.** A forward does not book onto a standing instrument: it books onto an
instrument **generated on the fly**, named:

```
MF_FWRD_<OrderID>_<YYYYMMDD>          forward deliverable
MF_NDF_FWRD_<OrderID>_<YYYYMMDD>      non-deliverable forward
```

`OrderID(37)`, non `ClOrdID(11)`: il primo e' stabile per tutta la vita dell'ordine, il
secondo cambia a ogni amend e spezzerebbe i fill di una stessa operazione su strumenti
diversi. TAB lo legge da `TNPDEAL.TNPMARKETORDERID.szMarketOrderId`.

La **value date fa parte del nome** (decisa il 28/08/2026). Su un forward singolo rende
lo strumento autodescrittivo; su uno swap FX e' cio' che distingue le due gambe, che
nascono dallo stesso ordine e portano quindi lo stesso `OrderID` - near e far
differiscono solo per data. Una convenzione sola invece di un suffisso di ruolo.

> Naming decided by the user on 26/08/2026, superseding the earlier `CCY1 CCY2 EXPIRY Orderid`.
> Confirmed live: without this, a forward books **exactly like a spot**, on the same currency
> instrument — which is wrong. The FX-forward instrument type in PRIME is a different one and
> has to be created per order. Work in progress in `developments/fwd_instrument/`.

So the instrument identity is derived from the currency pair, the value date, and the originating
order id — which means it is **unique per order**. Design accordingly:

- generation must be deterministic and idempotent — a retry, an amend or a replayed
  `ExecutionReport` must resolve to the *same* instrument, never a duplicate;
- the exact format of each component (separator, currency order, `EXPIRY` date format, which order
  id — ours or the provider's) must be pinned down and written here once confirmed;
- amends that change the value date change the instrument name: decide whether that means a new
  instrument, and what happens to the old one.

### Order types supported by the pricer

Source: `documentazione/pricer_supported_orders.png` (highlighted rows).
Note the table mixes two FIX concepts — `OrdType(40)` and `TimeInForce(59)`. Both dimensions apply.

| FIX order type      | Front Arena name                  | FIX encoding              |
|---------------------|-----------------------------------|---------------------------|
| Market order        | Best order                        | `OrdType(40)=1`           |
| Limit order         | Limit order                       | `OrdType(40)=2`           |
| Stop market         | Trigger market order (unlimited)  | `OrdType(40)=3` + `StopPx(99)` |
| Stop limit          | Trigger limit order               | `OrdType(40)=4` + `StopPx(99)` + `Price(44)` |
| Day order           | Good for day (GFD)                | `TimeInForce(59)=0`       |

| Immediate or Cancel | Fill and kill (FAK)               | `TimeInForce(59)=3`       |
| Fill or Kill        | Fill or kill (FOK)                | `TimeInForce(59)=4`       |
| Good till Date      | Date order (GTD)                  | `TimeInForce(59)=6` + `ExpireDate(432)`/`ExpireTime(126)` |

**Explicitly out of scope** — supported by the AMAS FIX toolkit but **not** by us:
MaxShow/MaxFloor, Market-to-Limit, Pegged limit, Pegged market, Amount order, Minimum quantity
order, **GTC** (`TimeInForce(59)=1`) and the three auction validities.

> Dropped on 28/08/2026 by the user's decision. GTC had started out supported: an order that
> never expires has to be carried by the provider across sessions, and until that is agreed a
> date order (GTD) says the same thing with an end to it. The auction validities went with it,
> being exchange concepts an FX pricer has no use for. **Only good for day and good till date
> remain.** Both halves are enforced: removed from the `DMC_FXFIX.xml` overlay so PRIME does
> not offer them, and refused by `_CM_IsValidEnterOrder` and `_CM_IsValidModifyOrder` so they
> cannot arrive by another route.
>
> The same overlay now leaves a single **market account**, `Client`. There is no registry
> setting for a default, and an order reaching AMAS without one is refused with "Market
> Account 0 is not an allowed value", so a one-value enum is how a default is obtained.

> These must be **rejected before they reach the wire**, with a clear reason back to PRIME.
> Never silently downgrade an unsupported order type to a supported one.

### Order lifecycle

- **New** — orders originate in PRIME and flow to the provider.
- **Amend** — PRIME can modify an order. **Only after the order has been acked** by the provider;
  an amend against an unacked order is an error on our side, not something to forward.
- **Cancel** — PRIME can cancel an order.
- **Partial fill** — supported. One order yields many `ExecutionReport`s; `LeavesQty`/`CumQty`/`AvgPx`
  must stay consistent across the sequence.
- **Reject** — the pricer can reject a new order, an amend, or a cancel. Rejects must propagate
  back to PRIME with the provider's reason preserved, never swallowed.

#### Unsolicited flow

A second, independent flow exists: **an `ExecutionReport` arrives from the market with no
originating order on our side**. There is nothing in PRIME to match it against.

This is not an error and must never be dropped or rejected as "unknown order". It has to be
recognised as unsolicited and booked as a trade in Front Arena (the trade-capture path the
`_CM_ExecutionReport2MCDEAL*` macros hint at).

Consequences to design for:

- order-state lookup **must tolerate a missing/unknown `ClOrdID(11)`** — no crash, no reject;
- the two flows are distinct code paths and must be tested separately;
- an unsolicited execution can also be amended or busted later — decide how that is handled;
- confirm with the provider how it marks these messages (`ExecType(150)`, `OrdStatus(39)`,
  what it puts in `ClOrdID`/`OrderID(37)`) — see [Open decisions](#open-decisions).

### Booking portfolio — `Account(1)`

The **booking portfolio travels in `Account(1)`**.

- We **send** it on every outbound order (`NewOrderSingle`, `OrderCancelReplaceRequest`,
  `OrderCancelRequest`).
- We **expect it back, in the same field**, on **every** `ExecutionReport` — including
  unsolicited ones.

An `ExecutionReport` without `Account(1)`, or with an `Account` that does not match the order's,
is a defect: surface it loudly, do not guess the portfolio or fall back to a default.

## FIX profile

**Version:** FIX 5.0 SP2 application layer over FIXT.1.1 session layer
(`DefaultApplVerID(1137)=9`).

**Outbound (us → provider)**

| Msg | Type | Notes |
|-----|------|-------|
| `NewOrderSingle` | `D` | new order |
| `OrderCancelReplaceRequest` | `G` | amend; carries `OrigClOrdID(41)` |
| `OrderCancelRequest` | `F` | cancel; carries `OrigClOrdID(41)` |

**Inbound (provider → us)**

| Msg | Type | Notes |
|-----|------|-------|
| `ExecutionReport` | `8` | ack, fills, cancels, replaces, rejects |
| `OrderCancelReject` | `9` | amend/cancel refused — `CxlRejResponseTo(434)`, `CxlRejReason(102)` |
| `BusinessMessageReject` | `j` | malformed/unsupported business message |

**Session:** `Logon(A)`, `Logout(5)`, `Heartbeat(0)`, `TestRequest(1)`, `ResendRequest(2)`,
`SequenceReset(4)`, `Reject(3)`.

**`ExecType(150)` we must handle:** `0` New, `A` PendingNew, `F` Trade (partial & full),
`4` Canceled, `5` Replaced, `6` PendingCancel, `E` PendingReplace, `8` Rejected, `C` Expired.

**Core tags:** `Account(1)` (booking portfolio — mandatory both ways), `ClOrdID(11)`,
`OrigClOrdID(41)`, `OrderID(37)`, `ExecID(17)`, `ExecType(150)`,
`OrdStatus(39)`, `Side(54)`, `OrderQty(38)`, `Price(44)`, `StopPx(99)`, `LastQty(32)`, `LastPx(31)`,
`LeavesQty(151)`, `CumQty(14)`, `AvgPx(6)`, `Symbol(55)`, `Currency(15)`, `Product(460)=4` (CURRENCY),
`SecurityType(167)`, `SettlType(63)`, `SettlDate(64)`, `OrdRejReason(103)`, `Text(58)`.

**FX-specific tags to settle per instrument:** forwards → `SettlDate(64)`/`SettlType(63)`;
swaps → near/far legs; options → `StrikePrice(202)`, `PutOrCall(201)`, `MaturityDate(541)`,
`ExerciseStyle(1194)`. See [Open decisions](#open-decisions).

**Invariants**

- `ClOrdID` is unique per session per day; every amend/cancel chains via `OrigClOrdID`.
- One in-flight amend or cancel per order at a time; queue or reject, never race.
- Reconcile `LeavesQty` against our own state on every `ExecutionReport`; a mismatch is a bug,
  not something to paper over.
- `Account(1)` is present on every outbound order and on every inbound `ExecutionReport`.
- An `ExecutionReport` with no matching order is **unsolicited**, not an error — route it to
  trade capture.

## Where the code lives

### AMAS customisations

**Hard rule:** all AMAS customisations live in the **`Customized` folder in the AMAS installation
root**. That is the only place the service picks them up from.

`amas customizations/` in this repo is the **mirror of that folder** — the versioned source of
truth. Work here, then deploy to `<AMAS_INSTALL_ROOT>/Customized`. Never hand-edit files directly
in the installation root: changes made there are invisible to this repo and get overwritten.

Current contents:

| File | Purpose |
|------|---------|
| `customisedInclude.map` | `SecurityType=FOR` for `TNP_CURRENCY`; NDF settlement currency and `CCY1/CCY2` symbol stored on the order book as it arrives from TAB; rejection of the order types the pricer does not support, on entry and on modify |
| `customisedFunctions.map` | `getFXSettlementCurrency()` — reads the NDF settlement currency back off the order book |
| `DMC_FXFIX.xml` | DMC overlay: trims the order types PRIME offers, merged onto FIS's `DMC_FIXTK2.xml` |

`CustomisedContributionOrderBooks_Macros.map` was retired — nothing in `AIF`, `Setup` or
`Customised` included it, and the macro it defined belongs to the XML reference-data flow,
which this integration does not use.

### Reproducibility — `developments/`

**Everything developed and tested must be reproducible by someone else, from this repo alone.**

A **copy of every piece of work done goes in `developments/`**: configs, map files as deployed,
simulator scenarios, test data, scripts, and the notes needed to re-run it. If a result cannot be
reproduced from what is in `developments/`, the work is not finished.

Practically, for each change:

- the artefacts as actually deployed (not a cleaned-up version)
- the simulator scenario(s) that exercise it
- the steps to run it — exact commands, not prose
- what the expected output is, so a rerun can be judged pass/fail

`developments/amba_configs/` already exists for AMBA configuration and is currently empty.

## Simulator

Repo: <https://github.com/giogandola98/fix-flow-simulator> — visual FIX scenario designer + runtime.
Java 21 / Spring Boot / QuickFIX/J, React UI, embedded H2. Speaks FIX 4.2, 4.4 and 5.0 SP2 (FIXT.1.1).
Source-available licence; commercial use needs separate licensing.

**Pin the latest beta: `v0.5.0-beta`** (adds end-to-end FIX repeating-group support — needed for
swap legs and option structures). Do not silently move off this tag; if you upgrade, say so.

```bash
mvn clean package -DskipTests
java -jar fix-flow-api/target/fix-flow-api-*.jar
# UI at http://localhost:8080
```

Prerequisites: Java 21+, Maven 3.9+, Node.js 20+.

The simulator stands in for the pricer, so it must be driven to produce the **unhappy paths too**:
partial fills in several chunks, amend rejected, cancel-too-late, reject on new, expiry on GTD,
FOK that cannot be filled.

Simulator scenarios are project artefacts: export them and keep them under `developments/`.
Clicking through the UI is exploration, not verification.

## Repo layout

| Path | What it is |
|------|-----------|
| `amas customizations/` | mirror of `<AMAS_INSTALL_ROOT>/Customized` — all AMAS customisations (TNP syntax `.map` files) |
| `developments/` | reproducible copy of all work done: configs, scenarios, test data, run instructions |
| `developments/amba_configs/` | AMBA configuration — empty, to be defined |
| `tab customizations/` | mirror of `<TAB_ROOT>/Msrv/python/custom` — TAB customisations (Python) |
| `HANDOVER.md` | current state, environment, immediate next steps |
| `documentazione/FCA4470-43.pdf` | Front Arena AMAS / FIX Toolkit documentation. §6.1.9 order free texts, §6.1.11 order-book free texts, §8.2 registry settings |
| `documentazione/FCA4853-11.pdf` | Front Arena TAB documentation — customisation point in §5.9 |
| `documentazione/pricer_supported_orders.png` | supported order-type matrix (source of truth for scope) |
| `documentazione/FIX50SP2_FX_OrderEntry_EN.pdf` | **the provider's own FIX spec** — Spot / Forward Outright / NDF, `NewOrderSingle` and `ExecutionReport`, with full worked examples. Source of truth for what goes on the wire |

`documentazione/FCA1192-65.pdf` is the AMS Configuration Reference — registry settings, and
§3.6.5 for the DMC Enricher.

**Not in this repo, but on the machine**: `E:\FrontArena\AMS\AMAS_FXL\Documentation\Documentation.zip`
is the AMAS-FIX Toolkit2 reference for **wrappers, constants and map functions**, plus the
FIX.4.2 / 4.3 / 4.4 / **5.0SP2** message and field definitions (FCA4470-43 §6.1.1). Unzip and
open `index.htm`. Use it when building outbound FIX messages.

**Missing and needed**: the **TNP-SDK documentation**. The conventions below tell you to consult
it for the TNP protocol, but it is not in `documentazione/` and not on the machine. Without it
the layout of TNP records — e.g. `TNPFREETEXTFORMAT` — cannot be read; `_TnpMaster.py` carries
message names and enums only. Get it from the installation kit.

## Working conventions

- **Read the docs first.** The AMAS and TAB PDFs in `documentazione/` are the authority for the
  Front Arena side. Consult them before designing anything that touches AMAS or TAB.
- **Test-first.** Write the failing test (or the simulator scenario) before the implementation.
- **Every FIX behaviour gets a simulator scenario**, checked into `developments/` alongside the code.
- **No invented FIX semantics.** If a tag, enum or workflow is not confirmed by the FIX 5.0 SP2 spec,
  the FA docs, or the provider spec, put it in [Open decisions](#open-decisions) and ask.
- **`.map` files** use TNP syntax. Follow the existing style: comment each macro with its purpose and
  cite the FA doc page (`//static data mapping FCA4470-43 page 24`). Per the toolkit header,
  **do not call SunGard-internal functions from `FIXOrderCommonFunctions.map`**.
  Remove the debug `system.success(...)` traces before anything ships.
- **Folder names contain spaces** (`amas customizations`) — always quote paths in shell commands.
- **Windows host, PowerShell primary.** Bash is available; don't mix syntaxes in one command.
- **Everything written is in English, without exception** — comments, docstrings, log and
  error strings, and the `README`s and notes under `developments/`. Only the conversation
  with the user is in Italian. This supersedes the earlier rule that allowed Italian notes
  in `developments/`: those are being converted.
- **Every source file carries `Author: GGIR` in its header** — `.py`, `.map`, `.xml`,
  simulator scenarios. In a Python file it goes in the module docstring, in a `.map` in the
  leading comment block.

## Open decisions

Do not resolve these by guessing — raise them.

1. **Split of responsibility.** What is done in AMAS map/config vs in TAB vs in AMBA config.
   Whether any separate adapter component is needed at all, and if so its stack.
2. **Session topology.** Who is initiator vs acceptor, CompIDs, host/port, TLS, heartbeat interval,
   sequence-reset and start-of-day policy, expected trading hours.
3. ~~**Symbology.**~~ **Closed for spot, forward and NDF** by the provider spec: `Symbol(55)` is
   always `A/B`, `OrderQty(38)` is in base currency `A`, and `Currency(15)` is the price
   currency `B`. `CashOrderQty(152)` is not used. That is exactly what
   `orderBooksFdb.MarketInstrumentTradingId` now carries (`MarketInstrumentId` + `/` +
   `TradingCurrency`). Still open for **swaps and options**, which the spec does not cover.
4. ~~**Currency universe.**~~ **Closed.** 59 currencies, 1656 pairs, direction by ACI convention.
   The non-deliverable flag is `SetScalFXFixingDateRule` on `FCurrencyPair` (a `Non-Deliverable`
   fixing date rule, `NDF_T-2`). Per-currency deliverability now lives in the `DELIVERABLE`
   AddInfo on the currency. See `developments/currency_pairs/README.md`.
5. **Forward value date.** The **FIX side is now pinned** by the provider spec: on a forward and on
   an NDF, `SettlType(63)=6` (FutureDate) is *the only accepted value* and `SettlDate(64)` is
   mandatory; on a spot neither is sent, `63=0` Regular is implied. `Price(44)` on a forward is the
   **all-in price** (spot + forward points), not the spot rate.
   The **PRIME side has an interim answer**: the value date is typed as `YYYYMMDD` in the order's
   **Reference** field, freed from `Text(58)` by blanking `MI\Parameters\MapTNPReference`, and
   mapped by `_CM_FX_SET_SETTLEMENT`. Interim because PRIME never requests free text formats from
   AMAS — see `developments/value_date/`. Still open: the exact `CCY1 CCY2 EXPIRY Orderid` format
   of the on-the-fly booking instrument (separators, date format, which order id).
6. **Unsolicited executions.** How the provider marks them, and what identifies the instrument,
   portfolio and counterparty. Also: what happens if one is later amended or busted.
7. ~~**`SecurityType(167)`.**~~ **Closed by the provider spec** (`FIX50SP2_FX_OrderEntry_EN.pdf`,
   p. 1): only `FXSPOT` / `FXFWD` / `FXNDF` are accepted, one per instrument type, and
   **`167=FOR` is explicitly not supported and must be rejected**.
   > ⚠️ `customisedInclude.map` currently forces `FOR` in `_CM_FC_MAP_SecurityType`. That is
   > now known to be wrong and has to be replaced by the three-way mapping.
8. **FX Swap shape.** One order with near/far legs (multileg repeating group) or two linked single
   orders? Drives whether we need the simulator's repeating-group support.
9. **FX Vanilla Option shape.** Premium, strike, expiry vs delivery date, cut, exercise style,
   and how the pricer quotes them.
10. **Fill-back into Front Arena.** The `_CM_ExecutionReport2MCDEAL*` macros suggest a trade-capture
   path already exists. Confirm whether fills book back through it, and what happens on amend/bust.
11. **Rejection contract.** Which `OrdRejReason(103)`/`CxlRejReason(102)` codes the pricer uses, and
    how they surface in PRIME.
12. **`Account(1)` values.** Which portfolio identifier the provider expects — the FA portfolio name,
    a mapped code, or a provider-side account. Confirm before the first order is sent.
13. **AMAS installation root path** on the target environment, and how deployment from
    `amas customizations/` to `Customized` is performed (script? manual? which environments?).
14. ~~**Version control.**~~ **Closed.** Il repo e' sotto git. Il core Python di PRIME
    esportato in `prime_python_export/Default/` e' escluso via `.gitignore`: e' codice
    di Front Arena, 17 MB, riesportabile da PRIME quando serve.

## Glossary

| Term | Meaning |
|------|---------|
| **PRIME** | Front Arena front-office application where orders originate; does not speak FIX directly |
| **AMAS** | Front Arena Arena Messaging and Adaptation Server — the service that speaks FIX for PRIME |
| **AMAS-FIX Toolkit 2** | FA component translating between TNP and FIX, customised via `.map` files in `Customized` |
| **`Customized`** | folder in the AMAS installation root; the only location AMAS loads customisations from |
| **TNP** | Front Arena internal protocol; the syntax used in `.map` files |
| **AMBA** | Front Arena messaging component — configs under `developments/amba_configs` (scope TBD) |
| **TAB** | Front Arena component under `tab customizations`; documented in `FCA4853-11.pdf` (scope TBD) |
| **Pricer** | The external provider that prices and executes our orders — **not yet built, simulated** |
| **FAK / FOK / GFD / GTC / GTD** | Fill-and-kill (IOC), fill-or-kill, good-for-day, good-till-cancel, good-till-date |

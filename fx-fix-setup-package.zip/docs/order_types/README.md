# Tipi di ordine non supportati dal pricer

Rifiuto, prima che l'ordine diventi un `NewOrderSingle` o un
`OrderCancelReplaceRequest`, dei tipi che il pricer non tratta. Piu' una regola sugli
order book swap.

Data: 2026-08-25.

## Cosa viene rifiutato

Le righe **non** evidenziate di `documentazione/pricer_supported_orders.png`. La stessa
tabella e' in FCA4470-43 par. 2.4.5, dove il toolkit le dichiara tutte supportate: sono
supportate da AMAS, non dal pricer.

| riga della tabella | campo TNP |
|---|---|
| Market To Limit | `TNPORDER.dwPriceCondition == TNP_PC_MARKETTOLIMIT` → `OrdType=K` |
| Pegged limit order | `TNP_PC_PEGLIMITED` → `OrdType=P` |
| Pegged market order | `TNP_PC_PEGUNLIMITED` → `OrdType=P` |
| MaxShow/MaxFloor | `TNPORDER.dwQuantityCondition == TNP_QC_HIDDENSIZE` |
| Minimum quantity order | `TNP_QC_MINIMUMQUANTITY` |
| Amount order | `TNPQUANTITYDIMENSION.dwQuantityDimension == TNP_QD_AMOUNT` |

La corrispondenza fra riga e campo viene dalle due tabelle di conversione del toolkit,
`CASE_PriceCondition2OrdType` e `CASE_TriggerCondition_PriceCondition2OrdType`
(`FIXCommon/fix_functions.map:1531` e `:1383`).

La stessa regola vale sulla **modifica**: senza, un ordine entrato come limit e poi
modificato in pegged aggirerebbe il blocco.

**In piu'**: su un order book con `InstrumentType` swap passa solo il **market order**.
Market e' `OrdType(40)=1`, che nasce da `TNP_PC_UNLIMITED` **e** trigger condition
diversa da `TNP_TC_REFERENCE_PRICE` - con quella stessa price condition e il trigger,
la conversione produce `OrdType=3`, stop market. La guardia chiede entrambe le cose.

### E' una blacklist, non una whitelist

Scelta esplicita. `dwPriceCondition` ha 16 valori (`_TnpMaster.py:6259-6282`), la tabella
del pricer ne nomina 4: **`MIDPOINTLIMITED`, `MIDPOINTUNLIMITED`, `EQUILIBRIUMPRICE`,
`MARKETTOLIMITONOPEN`, `ONECANCELSTHEOTHER`, `DISCRETIONARY`, `STRIKEMATCHLIMITED`,
`STRIKEMATCHUNLIMITED`, `STRICTLIMIT`, `PERIODICAUCTIONLIMITED`,
`PERIODICAUCTIONUNLIMITED` e `TNP_QC_ALLORNOTHING` restano passanti.** Se PRIME riesce a
generarne uno, arriva al pricer.

## Dove si aggancia

FCA4470-43 par. 2.4.5, testuale:

> To change which order types are available in AMAS, the customisation point
> `_CM_IsValidEnterOrder` can be used.

`isValidEnterOrder()` (`FIXCommon/FIXOrder/FIXOrderCommonFunctions.map:1044`) torna `1`
se l'ordine va bene, un codice negativo altrimenti. Il codice viene tradotto in testo in
`"fsm/main/wait/wait/ENTERORDER/ENTERORDERREPLY_ERR"` (`FIXOrderCommon.map:3452`) e torna
a PRIME come `TNPERRORMESSAGE.szErrorMessage`.

```
ENTERORDER da PRIME
   -> isValidEnterOrder()                    FIXOrderCommonFunctions.map:1044
        -> _CM_FA_isValidEnterOrder          FIXTK: trigger condition, order book attivo
             -> _CM_IsValidEnterOrder        <-- la nostra regola
   -> f_retValue < 0 -> ENTERORDERREPLY_ERR  FIXOrderCommon.map:3452
        -> _CM_ENTERORDER2ENTERORDERREPLY_ERR    <-- il nostro testo

MODIFYORDER da PRIME
   -> isValidCommonModification()            FIXOrderCommonFunctions.map:323
        -> _CM_FA_isValidCommonModification  FIXTK: trigger condition/price
             -> _CM_IsValidModifyOrder       <-- la nostra regola
   -> f_retValue < 1 -> MODIFYORDERREPLY_ERR FIXOrderCommon.map:4717
        -> _CM_MODIFYORDER2MODIFYORDERREPLY_ERR  <-- il nostro testo
```

### Perche' proprio quegli hook per i testi

`_CM_wait_wait_ENTERORDER_ENTERORDERREPLY_ERR` e
`_CM_active_active_MODIFYORDER_MODIFYORDERREPLY_ERR` sembrano i punti giusti ma **sono
gia' definiti da FIXTK** (`FIXOrderFIXTKSpecific.map:1767` e `:1775`): ridefinirli fa
sparire la sua catena, compresa la normalizzazione `f_errCode = ifexist2(f_err, f_errCode)`
che serve a leggere il codice con lo stesso nome sui due percorsi. Gli hook lasciati vuoti
per i clienti sono `_CM_ENTERORDER2ENTERORDERREPLY_ERR` e
`_CM_MODIFYORDER2MODIFYORDERREPLY_ERR` (righe 46-47), ed e' li' che scriviamo. Per lo
stesso motivo il codice si legge sempre da **`f_errCode`**, mai da `f_err`.

Sul percorso modifica il testo e' ancora piu' necessario: la catena di `if` del core non
ha un ramo di default, quindi senza il nostro macro `szErrorMessage` resterebbe vuoto.

### Le due forme di MODIFYORDER

`isValidCommonModification()` gestisce due casi (`FIXOrderCommonFunctions.map:329` e
`:369`): l'ordine completo in `TNPORDER`, oppure `TNPORDERID` piu' i **field record** delle
sole cose che cambiano. Il nostro macro legge price/quantity/trigger condition da
entrambe le forme, e nella seconda usa `-1` come "campo non toccato".

L'**amount order** non serve ricontrollarlo sulla modifica: il core lo rifiuta gia' su
tutte e due le forme con `INVALID_MODIFICATION_FUNDAMOUNTORDER`
(`FIXOrderCommonFunctions.map:357` e `:391`).

Tutti e due i nostri macro di regola partono da `if (f_retValue == 1)`: girano dopo i
controlli di FIS e non devono sovrascrivere un rifiuto gia' deciso da loro.

| codice | testo verso PRIME |
|---|---|
| `-101` `INVALID_FX_ORDERTYPE` | `Order type not supported by the FX pricer` |
| `-102` `INVALID_FX_SWAP_ORDERTYPE` | `FX swap order book: only market (best) orders are supported` |

FIS usa da `-1` a `-8` (`FIXOrderDefines.map:20-27`), i nostri partono da `-101`.

## La costante numerica

`TNP_SWAP` **non compare in nessun map** del toolkit, a differenza di `TNP_CURRENCY`,
`TNP_PC_*` e `TNP_QD_AMOUNT`, che il core usa. Non c'e' prova che `mcpp` conosca quel
simbolo, e un errore di sintassi in `Customised\` lascia AMAS "Running" coi provider mai
aperti. Quindi e' una `#define` nostra col valore dell'enum TNP:

```
#define FX_INSTRUMENTTYPE_SWAP	12   // _TnpMaster.py:5684
```

Fonte: `TAB_FXO\Msrv\python\_TnpMaster.py`, lo stesso enum da cui viene `TNP_CURRENCY = 8`,
che nei map coincide col simbolo gia' in uso. Se un giorno si verifica che `mcpp` accetta
il simbolo, si sostituisce.

`TNP_QD_AMOUNT` invece si usa direttamente: il core lo referenzia in
`FIXOrderCommonFunctions.map:357`.

## Come si riesegue

1. Copiare `customisedInclude.map` in `E:\FrontArena\AMS\AMAS_FXL\Customised\`
   (`.prev` accanto e' l'ultima versione che ha compilato).
2. Riavviare **AMAS_FXL** da AMS Management.

## Come si verifica

**Che abbia compilato**, subito dopo il riavvio - e' la verifica che conta di piu':

- event log di AMAS all'avvio senza errori di `mcpp`;
- TCP su `DESKTOP-VLEO563:6693` e `127.0.0.1:7000` risponde;
- in PRIME `acm.FMarketPlace['FX_LINK'].ConnectionStatus()` = `Connected`.

Se non compila, rimettere `customisedInclude.map.prev` e riavviare.

**Che rifiuti** - manuale, da PRIME, non c'e' scenario simulatore perche' per definizione
l'ordine non arriva al filo:

| ordine su order book FX | atteso |
|---|---|
| pegged, market-to-limit, iceberg, min quantity | rifiuto, `Order type not supported by the FX pricer` |
| limit o market | passa |
| su order book swap: qualunque cosa diversa da best order | rifiuto, `FX swap order book: only market...` |
| su order book swap: best order | passa |

E sulla modifica, che e' il caso che conta di piu':

| modifica di un ordine gia' acked | atteso |
|---|---|
| limit -> pegged, o -> market-to-limit | rifiuto, `Order type not supported by the FX pricer` |
| limit -> iceberg o min quantity | rifiuto, stesso testo |
| solo prezzo o quantita' | passa |
| su order book swap: market -> limit | rifiuto, `FX swap order book: only market...` |

## Cosa resta aperto

- **La lista che AMAS dichiara a PRIME.** Vedi sotto: il rifiuto qui e' a valle, PRIME
  continua a *offrire* i tipi non supportati nella sua order entry.

## La lista dei tipi offerti da PRIME - DMC

Il rifiuto qui sopra e' a valle: l'utente inserisce l'ordine e lo vede tornare indietro.
Quello che PRIME **offre** nella maschera lo decide il **DMC, Dynamic Market
Capabilities** (FCA4470-43 par. 2.3):

> AMAS supports DMC (Dynamic Market Capabilities) for clients that can handle this (for
> example, a new PRIME/OMNI). DMC specifies a lot of AMAS functionality, for example,
> supported order types and properties on different objects.

Sono due livelli diversi e servono tutti e due: il DMC toglie la voce dalla maschera, il
rifiuto ferma l'ordine se arriva lo stesso.

### Com'e' fatto

Il **DMC Enricher** (`Msrv\DMCEnricher.dll`, FCA1192 par. 3.6.5) risponde alla richiesta
TNP `GETMARKETCAPABILITIES` a partire da due XML:

| file | cos'e' |
|---|---|
| `Msrv\DMCModel.xml` | il **modello**: tutte le proprieta' dinamiche esistenti |
| `Msrv\DMC_FIXTK2.xml` | il **market server**: il sottoinsieme che questo AMAS supporta |

In `DMC_FIXTK2.xml` i tipi di ordine stanno in due enum sotto
`MarketCapability id="fixtkFull"`:

```
<Enum id="fixtkPriceConditions">     Limited, Unlimited, MarketToLimit, LimitedPeg, UnlimitedPeg
<Enum id="fixtkQuantityConditions">  Standard, FillOrKill, FillAndKill, Iceberg, MinimumQuantity
```

### Come lo riduciamo senza toccare gli XML di FIS

FCA1192 par. 3.6.5 e' esplicito: *"it is not recommended to change the content of any of
the deployed XML files"*. Ma la stessa sezione dice che
`Modules\DMCEnricher\Parameters\XmlAMASDescriptionFile` accetta una **lista di file
separati da virgola**, uniti nell'ordine in cui compaiono, e che
**`MergeAction="Replace"`** su un elemento sostituisce quell'elemento e tutti i suoi figli
invece di unirli.

Quindi: `DMC_FIXTK2.xml` resta intatto e si aggiunge **`DMC_FXFIX.xml`** (in
`Customised\`, non in `Msrv\`, con percorso assoluto nel registry) che ridichiara i due
enum con `MergeAction="Replace"`:

| enum | dopo |
|---|---|
| `fixtkPriceConditions` | `Limited`, `Unlimited` |
| `fixtkQuantityConditions` | `Standard`, `FillOrKill`, `FillAndKill` |

Via quindi Market-to-limit, i due peg, Iceberg (= MaxShow/MaxFloor) e Minimum quantity.
L'**Amount order** non compare in questi enum: dipende dagli `OrderBookAttributes`
dell'order book, che sulle coppie valuta non sono valorizzati.

### Perche' PRIME leggeva il DMC sbagliato

Il DMC Enricher era **gia' attivo** (`Modules\DMCEnricher\Active = 1`). Il problema era
un altro, ed e' il caso descritto in FCA4470-43 par. 9.19: sugli order book presi da
**TNP reference data** - i nostri, che arrivano da TAB - il client usa il DMC
dell'**home market server**, non quello del nostro AMAS, a meno che gli order book non
portino esplicitamente il nostro id di capability.

Stato trovato, dall'event log del 25/08/2026 alle 19:09:59:

```
TNPProvider settings: UseOwnAMASCapabilityID=0, MSC=16, SetDynamicMarketCapabilityId=0
```

Tutti e due a zero: PRIME leggeva le capability dell'ADS (capability 62), non le nostre
(16). Il fix e' `UseOwnAMASCapabilityID = 1`, che fa scrivere al toolkit
`SetDynamicMarketCapabilityId = MarketServerCapability` a ogni avvio e corregge un
eventuale disallineamento (`FIXTK/FIXOrder/FIXOrderFIXTKSpecific.map:479-495`).

### Come si applica

Il registry vive in `HKLM\SOFTWARE\Front\Front Arena\AMS\AMAS_FXL` - la chiave a 64
bit, sotto `WOW6432Node` non c'e' nessuna copia. Le tre voci sono in
**`dmc_capability.reg`**, da applicare **elevato**:

```
reg import dmc_capability.reg
```

poi riavviare `AMAS_FXL`. In alternativa si impostano da AMS Management / AIFConfig: la
voce *Change to own AMAS capability (for DMC)* e' quella di `UseOwnAMASCapabilityID`
(FCA4470-43 p.57, dove e' descritta come attiva di default dal 2024.1.0 - qui non lo era).

### Come si verifica

All'avvio di AMAS, nell'event log, la stessa riga di prima deve diventare:

```
TNPProvider settings: UseOwnAMASCapabilityID=1, MSC=16, SetDynamicMarketCapabilityId=16
```

Poi, in PRIME, la maschera d'inserimento ordine su un order book `FX_LINK` non deve piu'
offrire pegged, market-to-limit, iceberg e minimum quantity.

### Chiuso il 28/08/2026

Le domande lasciate aperte qui sopra sono state decise dall'utente, e `DMC_FXFIX.xml`
adesso restringe quattro enum invece di uno:

| Enum | Cosa resta | Perche' |
|------|-----------|---------|
| `fixtkQuantityConditions` | Standard, FOK, IOC | Iceberg e MinimumQuantity sono esclusi dal pricer |
| `fixtkValidityConditions` | GoodForDay, GoodTillTime | via GTC e le tre condizioni d'asta |
| `fixtkPriceConditions` | Limited, Unlimited | via MarketToLimit e i due Peg |
| `fixtkTriggerCondition` | None, Price | nessuna rimozione: fissa cio' che FIS gia' offre |
| `fixtkMarketAccounts` | Own | un valore solo, cosi' e' di fatto il default |

Tre note su queste scelte.

**Il GTC era supportato.** E' l'unica riga della tabella del pricer che passa da
supportata a esclusa. Un ordine che non scade mai va portato dal provider attraverso le
sessioni, e finche' non e' concordato un ordine a data dice la stessa cosa con una fine.
Le condizioni d'asta se ne vanno con lui: sono concetti di borsa, un pricer FX non ha
un'asta di apertura in cui trattenere un ordine.

**Il market account non ha un default configurabile.** Non esiste una chiave di registro:
l'unico modo di ottenerne uno e' lasciare un valore solo nell'enum, perche' PRIME non
abbia altro da scegliere. Serve, perche' un ordine che arriva ad AMAS senza market account
viene rifiutato con *"Market Account 0 is not an allowed value"*.

**Lo stop non e' una voce sola.** I quattro tipi supportati sono il prodotto di due enum,
non quattro righe da qualche parte:

```
No trigger + Market = market order      Stop + Market = stop order
No trigger + Limit  = limit order       Stop + Limit  = stop limit
```

`displayNameDefault` nomina una voce, non una combinazione, quindi "stop order" e
"stop limit" sono cio' che le due tendine **leggono insieme**. Da verificare in PRIME:
FIS mette `displayNameDefault` solo sulle validity condition, quindi non e' detto che la
order entry lo legga anche per queste due.

- **Resta aperto** il resto dell'alternativa di FCA4470-43 par. 9.19: disattivare il DMC
  per il mercato lato PRIME e usare capability statiche
  (`FOrderBook:marketDynamicMarketCapabilities'FX_LINK' = false`). Non serve, la strada
  del DMC funziona.
- **Resta aperto** togliere le proprieta' `Hidden` (MaxShow) e `BuyOrSellType`
  (SellShort/SellShortExempt): sono proprieta', non enum, e non ho trovato in nessuna
  documentazione locale quale `MergeAction` rimuova una proprieta'. `Replace` e' l'unico
  valore in uso e l'unico verificato. `Hidden` e' comunque coperto altrove: l'Iceberg e'
  gia' fuori da `fixtkQuantityConditions` e `TNP_QC_HIDDENSIZE` e' rifiutato da
  `_CM_IsValidEnterOrder`.

### Trappola di sintassi trovata deployando (25/08/2026)

`_CM_IsValidModifyOrder` conteneva `f_fxPc >= 0`. **Il linguaggio dei map non ha `>=`
ne' `<=`**: in tutto `AIF\Packages` non c'e' una sola occorrenza in codice, solo una in
un commento. Il parser fallisce all'avvio e — cosa che fa perdere tempo — punta al
simbolo sbagliato:

```
line 325: syntax error at "f_fxPc"; "f_fxPc" not in
          { Eof SEMICOLON DOT ... LSQUARE RSQUARE DIVIDE FROM FOR IF NOT IN
            LessThan OR AND TO FROMNOTCONST CONST ID DCONST QCONST < > == != }
```

L'indizio e' nell'elenco dei token attesi: ci sono `<` `>` `==` `!=`, non `>=`.
Scritto `f_fxPc > -1`, equivalente su interi.

Verificate per esclusione nella stessa sessione, **due cose che non sono il problema**,
utili per non ripetere il giro:

- piu' assegnazioni consecutive nel corpo di una macro vanno bene, anche se il `\` di
  continuazione le unisce tutte su una riga sola;
- il `;` **non** e' un separatore di statement: aggiungerlo da
  `syntax error at ";" missing RCURLY`.

Il ciclo di prova e' `Stop-Service AMAS_FXL` → copia del map in `Customised\` →
`Start-Service` → si guarda l'event log; circa un minuto a giro. Un errore di sintassi
lascia il servizio in loop di restart (`ServerGuard: AMAS_FXL terminated - Restarting`),
quindi va fermato esplicitamente prima di riprovare.

## Ordini stop: il messaggio di trigger `ExecType(150)=L` non serve

Punto aperto dello spec del pricer (`documentazione/FIX50SP2_FX_OrderEntry_EN.pdf`, par.
1.2, pag. 4): se allo scatto del livello mandare un `ExecutionReport` con `150=L`
(*Triggered or Activated by System*, `39=0`, `151` invariato, `14=0`), oppure andare
dritti al fill.

**Risposta: non serve. Su questa installazione non verrebbe nemmeno gestito.** Verificato
sull'installato, non dedotto.

1. Sia la mappatura sia la transizione dell'FSM esistono nel sorgente FIS, ma sono
   **filtrate per marketplace**:

   ```
   FIXOrderCommon.map:6462   #if defined(MP_BIST) || defined(MP_XETRA) || defined(MP_OPTIQ) || defined(MP_NND)
                             "fsm/FIXOrder/active/active/OrderProvider::ExecutionReport/MCMODIFYORDER_TRIGGERED"

   FIXOrderFsm.xml:761       @filter[MP_XETRA || MP_BIST || MP_OPTIQ || MP_NND]
                             guard: ExecType == 'L'   effect: onExecutionReport(), MCMODIFYORDER_TRIGGERED
   ```

   Sono Xetra, Borsa Istanbul, Euronext Optiq e NND: mercati azionari, niente a che
   vedere con noi.

2. Su questo AMAS **nessuno di quei simboli e' definito**: `MCMODIFYORDER_TRIGGERED`
   compare **0 volte** nel map preprocessato
   (`PreProcessed/FIXOrderCommon.map_anonymous1.map_pp`). La gestione di `150=L`
   semplicemente non e' compilata.

3. Anche dove e' attiva **non cambia lo stato dell'ordine**: e' una self-transition su
   `active` (source == target), coerente con il `39=0` che loro stessi indicano. Serve
   solo a *dirlo a PRIME*, azzerando `FSMTriggerCondition` e `FSMTriggerPrice` e mandando
   un `MCMODIFYORDER` con `TNP_MCFLAG_MODIFYCOMPLETE`.

4. Esiste un punto di customizzazione `_CM_FC_IsTriggered` (funzione `isTriggered()` in
   `FIXOrderCommonFunctions.map:2449`, guardia `isAccepted() || isTriggered()` in
   `FIXOrderFsm.xml:815`). Serve al caso opposto: mercati che **accettano** uno stop con
   `150=L` *invece* di `150=0`. Non e' il nostro caso, se l'ack resta `150=0`.

Quindi il ciclo che AMAS gestisce nativamente e' esattamente quello che loro propongono
come alternativa:

```
D  ->  8 (150=0, ack)  ->  8 (150=F, fill)
```

**Cosa si perde.** Nulla sulla correttezza: quantita', stato e fill restano coerenti.
L'unica differenza e' cosmetica lato PRIME — senza `150=L` un ordine stop in attesa
continua a mostrare trigger condition e trigger price finche' non arriva il fill, invece
di "diventare" un ordine normale allo scatto. Se un giorno lo si volesse, si scrive con i
due hook `_CM_active_active_ExecutionReport_MCMODIFYORDER_TRIGGERED[_2]`, ma va anche
ricreata la transizione, che qui non e' compilata.

### Altri due punti aperti dello stesso PDF, da girare alla controparte

- **Stop Limit (`40=4`)**, marcato *TO DISCUSS*: per noi **e' in scope**. La tabella
  `pricer_supported_orders.png` lo elenca fra i supportati ("Trigger limit order"), e il
  `CLAUDE.md` lo mappa `OrdType=4` + `StopPx(99)` + `Price(44)`. Va confermato supportato,
  non tolto.
- **Stop su NDF**: loro stessi notano che il trigger e' sul contract rate e non sul
  fixing, e che la sorgente del livello va concordata.
